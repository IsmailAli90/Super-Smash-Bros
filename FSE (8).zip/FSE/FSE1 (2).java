import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.MouseInfo;

public class FSE extends JFrame implements ActionListener{
    Timer myTimer;
    Menu game;
    int map = 0;
    boolean gamestart = false;
    int choosen1, choosen2;
    GamePanel gamePanel;

    public FSE(){
        super("FSE");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900,650);

        myTimer = new Timer(10, this);


        game = new Menu(this);
        add(game);

        setResizable(false);
        setVisible(true);
		myTimer.start();
    }

    public void start(){
    }

    public void actionPerformed(ActionEvent evt){
    	if (!gamestart) {

    		if (map != 0) {
    			gamestart = true;
    			getContentPane().removeAll();                          // Sn = a(r^n-1) Future Value: r is 1.something
				gamePanel = new GamePanel(choosen1, choosen2);              // -------- Present Value: r is 1/1.something
				add(gamePanel);                                             //   r-1    Simple Interest: A = P(1+i)^n
				setVisible(true);
				validate();
    			game = null;

				return;
			}
			game.move();
			game.repaint();
		} else {
    		gamePanel.requestFocus();
			gamePanel.refresh();
			gamePanel.repaint();
			gamePanel.update();
			gamePanel.collide();
		}
    }

    public static void main(String[] arguments) {
        FSE frame = new FSE();
    }
}
class Menu extends JPanel implements MouseListener{
	Image Stars,TimeBattle,LivesBattle,BottomSelect,P1Image,P2Image,P1Circle,P2Circle;
	Image DKSelect,MarioSelect,LinkSelect,PeachSelect,PikachuSelect,FalcoSelect,FoxSelect,CaptainSelect,SonicSelect,TailsSelect,LuigiSelect,RandomSelect;
	Image DKPose,MarioPose,LinkPose,PeachPose,PikachuPose,FalcoPose,FoxPose,CaptainPose,SonicPose,TailsPose,LuigiPose,Ready;
	Image DKIcon,MarioIcon,LinkIcon,PokemonIcon,FoxIcon,SonicIcon,CaptainIcon;
	Image PokemonArena,Arena,FinalArena,PokemonArenaBig,ArenaBig,FinalArenaBig;
	Image Num1,Num2,Num3,Num4,Num5,Num6,Num7,Num8,Num9,Num10;
	private int mouseX, mouseY;
	private int P1CircleX,P1CircleY,P2CircleX,P2CircleY,choosen,choosen2,map;
	private FSE mainFrame;
	boolean Choose1,Choose2,LBattle,TBattle,ready;
	int Lives=3;

	public Menu(FSE m){
		P1CircleX=150+25;
		P1CircleY=450+25;
		P2CircleX=700+25;
		P2CircleY=450+25;
		TBattle=true;
		Stars = new ImageIcon("Stars.png").getImage();
		Stars = Stars.getScaledInstance(900,650,Image.SCALE_SMOOTH);
		TimeBattle = new ImageIcon("TimeBattle.png").getImage();
		TimeBattle = TimeBattle.getScaledInstance(900,100,Image.SCALE_SMOOTH);
		LivesBattle = new ImageIcon("LivesBattle.png").getImage();
		LivesBattle = LivesBattle.getScaledInstance(900,100,Image.SCALE_SMOOTH);
		BottomSelect = new ImageIcon("SelectBottom.png").getImage();
		BottomSelect = BottomSelect.getScaledInstance(900,300,Image.SCALE_SMOOTH);
		P1Image = new ImageIcon("P1Image.png").getImage();
		P1Image = P1Image.getScaledInstance(200,275,Image.SCALE_SMOOTH);
		P2Image = new ImageIcon("P2Image.png").getImage();
		P2Image = P2Image.getScaledInstance(200,275,Image.SCALE_SMOOTH);
		P1Circle = new ImageIcon("P1Circle.png").getImage();
		P1Circle = P1Circle.getScaledInstance(50,50,Image.SCALE_SMOOTH);
		P2Circle = new ImageIcon("P2Circle.png").getImage();
		P2Circle = P2Circle.getScaledInstance(50,50,Image.SCALE_SMOOTH);

		DKSelect = new ImageIcon("DKSelect.png").getImage();
		DKSelect = DKSelect.getScaledInstance(75,75,Image.SCALE_SMOOTH);
		MarioSelect = new ImageIcon("MarioSelect.png").getImage();
		MarioSelect = MarioSelect.getScaledInstance(75,75,Image.SCALE_SMOOTH);
		LinkSelect = new ImageIcon("LinkSelect.png").getImage();
		LinkSelect = LinkSelect.getScaledInstance(75,75,Image.SCALE_SMOOTH);
		PeachSelect = new ImageIcon("PeachSelect.png").getImage();
		PeachSelect = PeachSelect.getScaledInstance(75,75,Image.SCALE_SMOOTH);
		PikachuSelect = new ImageIcon("PikachuSelect.png").getImage();
		PikachuSelect = PikachuSelect.getScaledInstance(75,75,Image.SCALE_SMOOTH);
		FalcoSelect = new ImageIcon("FalcoSelect.png").getImage();
		FalcoSelect = FalcoSelect.getScaledInstance(75,75,Image.SCALE_SMOOTH);
		FoxSelect = new ImageIcon("FoxSelect.png").getImage();
		FoxSelect = FoxSelect.getScaledInstance(75,75,Image.SCALE_SMOOTH);
		CaptainSelect = new ImageIcon("CaptainSelect.png").getImage();
		CaptainSelect = CaptainSelect.getScaledInstance(75,75,Image.SCALE_SMOOTH);
		SonicSelect = new ImageIcon("SonicSelect.png").getImage();
		SonicSelect = SonicSelect.getScaledInstance(75,75,Image.SCALE_SMOOTH);
		TailsSelect = new ImageIcon("TailsSelect.png").getImage();
		TailsSelect = TailsSelect.getScaledInstance(75,75,Image.SCALE_SMOOTH);
		LuigiSelect = new ImageIcon("LuigiSelect.png").getImage();
		LuigiSelect = LuigiSelect.getScaledInstance(75,75,Image.SCALE_SMOOTH);
		RandomSelect = new ImageIcon("RandomSelect.png").getImage();
		RandomSelect = RandomSelect.getScaledInstance(75,75,Image.SCALE_SMOOTH);

		DKPose = new ImageIcon("DKPose.png").getImage();
		DKPose = DKPose.getScaledInstance(200,200,Image.SCALE_SMOOTH);
		MarioPose = new ImageIcon("MarioPose.png").getImage();
		MarioPose = MarioPose.getScaledInstance(200,200,Image.SCALE_SMOOTH);
		LuigiPose = new ImageIcon("LuigiPose.png").getImage();
		LuigiPose = LuigiPose.getScaledInstance(200,200,Image.SCALE_SMOOTH);
		PeachPose = new ImageIcon("PeachPose.png").getImage();
		PeachPose = PeachPose.getScaledInstance(200,200,Image.SCALE_SMOOTH);
		PikachuPose = new ImageIcon("PikachuPose.png").getImage();
		PikachuPose = PikachuPose.getScaledInstance(200,200,Image.SCALE_SMOOTH);
		LinkPose = new ImageIcon("LinkPose.png").getImage();
		LinkPose = LinkPose.getScaledInstance(200,200,Image.SCALE_SMOOTH);
		CaptainPose = new ImageIcon("CaptainPose.png").getImage();
		CaptainPose = CaptainPose.getScaledInstance(200,227,Image.SCALE_SMOOTH);
		FoxPose = new ImageIcon("FoxPose.png").getImage();
		FoxPose = FoxPose.getScaledInstance(200,240,Image.SCALE_SMOOTH);
		SonicPose = new ImageIcon("SonicPose.png").getImage();
		SonicPose = SonicPose.getScaledInstance(200,200,Image.SCALE_SMOOTH);
		TailsPose = new ImageIcon("TailsPose.png").getImage();
		TailsPose = TailsPose.getScaledInstance(200,200,Image.SCALE_SMOOTH);

		MarioIcon = new ImageIcon("MarioIcon.png").getImage();
		MarioIcon = MarioIcon.getScaledInstance(50,50,Image.SCALE_SMOOTH);
		CaptainIcon = new ImageIcon("CaptainIcon.png").getImage();
		CaptainIcon = CaptainIcon.getScaledInstance(60,50,Image.SCALE_SMOOTH);
		DKIcon = new ImageIcon("DKIcon.png").getImage();
		DKIcon = DKIcon.getScaledInstance(50,50,Image.SCALE_SMOOTH);
		FoxIcon = new ImageIcon("FoxIcon.png").getImage();
		FoxIcon = FoxIcon.getScaledInstance(60,50,Image.SCALE_SMOOTH);
		LinkIcon = new ImageIcon("LinkIcon.png").getImage();
		LinkIcon = LinkIcon.getScaledInstance(50,50,Image.SCALE_SMOOTH);
		PokemonIcon = new ImageIcon("PokemonIcon.png").getImage();
		PokemonIcon = PokemonIcon.getScaledInstance(50,50,Image.SCALE_SMOOTH);
		SonicIcon = new ImageIcon("SonicIcon.png").getImage();
		SonicIcon = SonicIcon.getScaledInstance(50,50,Image.SCALE_SMOOTH);

		Num1 = new ImageIcon("Num1.png").getImage();
		Num1 = Num1.getScaledInstance(51,50,Image.SCALE_SMOOTH);
		Num2 = new ImageIcon("Num2.png").getImage();
		Num2 = Num2.getScaledInstance(51,50,Image.SCALE_SMOOTH);
		Num3 = new ImageIcon("Num3.png").getImage();
		Num3 = Num3.getScaledInstance(51,50,Image.SCALE_SMOOTH);
		Num4 = new ImageIcon("Num4.png").getImage();
		Num4 = Num4.getScaledInstance(51,50,Image.SCALE_SMOOTH);
		Num5 = new ImageIcon("Num5.png").getImage();
		Num5 = Num5.getScaledInstance(51,50,Image.SCALE_SMOOTH);
		Num6 = new ImageIcon("Num6.png").getImage();
		Num6 = Num6.getScaledInstance(51,50,Image.SCALE_SMOOTH);
		Num7 = new ImageIcon("Num7.png").getImage();
		Num7 = Num7.getScaledInstance(51,50,Image.SCALE_SMOOTH);
		Num8 = new ImageIcon("Num8.png").getImage();
		Num8 = Num8.getScaledInstance(51,50,Image.SCALE_SMOOTH);
		Num9 = new ImageIcon("Num9.png").getImage();
		Num9 = Num9.getScaledInstance(51,50,Image.SCALE_SMOOTH);
		Num10 = new ImageIcon("Num10.png").getImage();
		Num10 = Num10.getScaledInstance(51,50,Image.SCALE_SMOOTH);
		Ready = new ImageIcon("Ready.png").getImage();
		Ready = Ready.getScaledInstance(900,50,Image.SCALE_SMOOTH);

//		  Arena = new ImageIcon("Arena.png").getImage();
//		  Arena = Arena.getScaledInstance(900,217,Image.SCALE_SMOOTH);
//		  ArenaBig = new ImageIcon("Arena.png").getImage();
//		  ArenaBig = Arena.getScaledInstance(900,650,Image.SCALE_SMOOTH);

		PokemonArena = new ImageIcon("PokemonArena.png").getImage();
		PokemonArena = PokemonArena.getScaledInstance(900,325,Image.SCALE_SMOOTH);
		PokemonArenaBig = new ImageIcon("PokemonArena.png").getImage();
		PokemonArenaBig = PokemonArenaBig.getScaledInstance(900,650,Image.SCALE_SMOOTH);

		FinalArena = new ImageIcon("FinalArena.png").getImage();
		FinalArena = FinalArena.getScaledInstance(900,325,Image.SCALE_SMOOTH);
		FinalArenaBig = new ImageIcon("FinalArena.png").getImage();
		FinalArenaBig = FinalArena.getScaledInstance(900,650,Image.SCALE_SMOOTH);


		mainFrame=m;
		setSize(900,650);
		addMouseListener(this);
	}
	public void move(){
		Point mouse = MouseInfo.getPointerInfo().getLocation();
		Point offset = getLocationOnScreen();
		mouseX = mouse.x-offset.x;
		mouseY = mouse.y-offset.y;
		System.out.println(mouseX + "," + mouseY);
		if(Choose1==true){
			Choose2=false;
			P1CircleX+=mouseX-P1CircleX;
			P1CircleY+=mouseY-P1CircleY;
		}
		if(Choose2==true){
			Choose1=false;
			P2CircleX+=mouseX-P2CircleX;
			P2CircleY+=mouseY-P2CircleY;
		}
	}
	public void mouseEntered(MouseEvent e){}
    public void mouseExited(MouseEvent e){
    	Choose1=false;
    	Choose2=false;
    }
    public void mouseReleased(MouseEvent e) {
    	if(Choose1==true){
    		Choose1=false;
    		if(P1CircleY>=115 && P1CircleY<=190){
	    		if(P1CircleX>=225 && P1CircleX<=300){
	    			choosen=1;
	    		}
	    		if(P1CircleX>=300 && P1CircleX<=375){
	    			choosen=2;
	    		}
	    		if(P1CircleX>=375 && P1CircleX<=450){
	    			choosen=3;
	    		}
	    		if(P1CircleX>=450 && P1CircleX<=525){
	    			choosen=4;
	    		}
	    		if(P1CircleX>=525 && P1CircleX<=600){
	    			choosen=5;
	    		}
	    		if(P1CircleX>=600 && P1CircleX<=675){
	    			choosen=6;
	    		}
	    		if(P1CircleX<225 || P2CircleY>675){
    				choosen=0;
    		}
    	}
    		if(P1CircleY>=190 && P1CircleY<=265){
	    		if(P1CircleX>=263 && P1CircleX<=338){
	    			choosen=7;
	    		}
	    		if(P1CircleX>=338 && P1CircleX<=413){
	    			choosen=8;
	    		}
	    		if(P1CircleX>=488 && P1CircleX<=563){
	    			choosen=9;
	    		}
	    		if(P1CircleX>=563 && P1CircleX<=638){
	    			choosen=10;
	    		}
	    		if(P1CircleX<263 || P1CircleX>638){
    				choosen=0;
    		}
    	}
    		if(P2CircleY<115 || P2CircleY>265){
    			choosen2=0;
    		}
    	}
    	if(Choose2=true){
    		Choose2=false;
    		if(P2CircleY>=115 && P2CircleY<=190){
	    		if(P2CircleX>=225 && P2CircleX<=300){
	    			choosen2=1;
	    		}
	    		if(P2CircleX>=300 && P2CircleX<=375){
	    			choosen2=2;
	    		}
	    		if(P2CircleX>=375 && P2CircleX<=450){
	    			choosen2=3;
	    		}
	    		if(P2CircleX>=450 && P2CircleX<=525){
	    			choosen2=4;
	    		}
	    		if(P2CircleX>=525 && P2CircleX<=600){
	    			choosen2=5;
	    		}
	    		if(P2CircleX>=600 && P2CircleX<=675){
	    			choosen2=6;
	    		}
	    		if(P2CircleX<225 || P2CircleX>675){
	    			choosen=0;
	    		}
    		}
    		if(P2CircleY>=190 && P2CircleY<=265){
	    		if(P2CircleX>=263 && P2CircleX<=338){
	    			choosen2=7;
	    		}
	    		if(P2CircleX>=338 && P2CircleX<=413){
	    			choosen2=8;
	    		}
	    		if(P2CircleX>=488 && P2CircleX<=563){
	    			choosen2=9;
	    		}
	    		if(P2CircleX>=563 && P2CircleX<=638){
	    			choosen2=10;
	    		}
	    		if(P2CircleX<263 || P2CircleX>638){
	    			choosen2=0;
	    		}
    		}
    		if(P2CircleY<115 || P2CircleY>265){
    			choosen2=0;
    		}
    	}

		mainFrame.choosen1 = choosen;
		mainFrame.choosen2 = choosen2;
    }

    public void mouseClicked(MouseEvent e){
    	}
    public void mousePressed(MouseEvent e){
    	//g.drawRect(520,26,344,50);
    	
    /*	if(mouseX>520 && mouseX<865){
    		if(mouseY>25 && mouseY<77){
    			LBattle=!LBattle;
    			TBattle=!TBattle;
    		}
    	}*/
    	if(mouseX>=P1CircleX-25 && mouseX<=(P1CircleX+25)){
    		if(mouseY<=(P1CircleY+25) && mouseY>P1CircleY-25){
    			Choose1=true;
    		}
    	}
    	if(mouseX>=P2CircleX-25 && mouseX<=(P2CircleX+25)){
    		if(mouseY<=(P2CircleY+25) && mouseY>P2CircleY-25){
    			Choose2=true;
    		}
    	}
    	if(mouseY>=38 && mouseY<=68){
    		if(mouseX>=425 && mouseX<447){
    			if(Lives!=1){
    				Lives-=1;
    			}
    		}
    		if(mouseX>=498 && mouseX<=520){
    			if(Lives!=10){
    				Lives+=1;
    			}
    		}
    	}
    	if(choosen>0 && choosen2>0){
    		if(mouseX>=0 && mouseX<=900){
    			if(mouseY>=275 && mouseY<=325){
    				ready=true;
    				System.out.println(ready);
    			}
    		}
    	}
    }
    

    public void paintComponent(Graphics g){
    	if(ready==false){
    		g.drawImage(Stars,0,0,this);
	    	if(TBattle==true){
	    		g.drawImage(TimeBattle,0,0,this);
	    	}
	    	if(LBattle==true){
	    		g.drawImage(LivesBattle,0,0,this);
	    	}
	    	g.drawImage(BottomSelect,0,325,this);
	    	g.drawImage(P1Image,75,350,this);
	    	g.drawImage(P2Image,625,350,this);
	    	g.drawImage(MarioSelect,225,115,this);
	    	g.drawImage(LuigiSelect,300,115,this);
	    	g.drawImage(PeachSelect,375,115,this);
	    	g.drawImage(DKSelect,450,115,this);
	    	g.drawImage(PikachuSelect,525,115,this);
	    	g.drawImage(LinkSelect,600,115,this);
	    	g.drawImage(CaptainSelect,263,190,this);
	    	g.drawImage(FoxSelect,338,190,this);
	    	g.drawImage(RandomSelect,413,190,this);
	    	g.drawImage(SonicSelect,488,190,this);
	    	g.drawImage(TailsSelect,563,190,this);

	    	if(choosen==1){
	    		g.drawImage(MarioIcon,220,355,this);
	    		g.drawImage(MarioPose,75,355,this);
	    	}
	    	if(choosen==2){
	    		g.drawImage(MarioIcon,220,355,this);
	    		g.drawImage(LuigiPose,75,355,this);
	    	}
	    	if(choosen==3){
	    		g.drawImage(MarioIcon,220,355,this);
	    		g.drawImage(PeachPose,75,355,this);
	    	}
	    	if(choosen==4){
	    		g.drawImage(DKIcon,220,355,this);
	    		g.drawImage(DKPose,75,355,this);
	    	}
	    	if(choosen==6){
	    		g.drawImage(LinkIcon,220,355,this);
	    		g.drawImage(LinkPose,75,355,this);
	    	}
	    	if(choosen==5){
	    		g.drawImage(PokemonIcon,220,355,this);
	    		g.drawImage(PikachuPose,75,355,this);
	    	}
	    	if(choosen==7){
	    		g.drawImage(CaptainIcon,210,355,this);
	    		g.drawImage(CaptainPose,75,345,this);
	    	}
	    	if(choosen==8){
	    		g.drawImage(FoxIcon,210,355,this);
	    		g.drawImage(FoxPose,75,330,this);
	    	}
	    	if(choosen==9){
	    		g.drawImage(SonicIcon,220,355,this);
	    		g.drawImage(SonicPose,75,355,this);
	    	}
	    	if(choosen==10){
	    		g.drawImage(SonicIcon,220,355,this);
	    		g.drawImage(TailsPose,75,355,this);
	    	}

	    	if(choosen2==1){
	    		g.drawImage(MarioIcon,220+550,355,this);
	    		g.drawImage(MarioPose,75+550,355,this);
	    	}
	    	if(choosen2==2){
	    		g.drawImage(MarioIcon,220+550,355,this);
	    		g.drawImage(LuigiPose,75+550,355,this);
	    	}
	    	if(choosen2==3){
	    		g.drawImage(MarioIcon,220+550,355,this);
	    		g.drawImage(PeachPose,75+550,355,this);
	    	}
	    	if(choosen2==4){
	    		g.drawImage(DKIcon,220+550,355,this);
	    		g.drawImage(DKPose,75+550,355,this);
	    	}
	    	if(choosen2==6){
	    		g.drawImage(LinkIcon,220+550,355,this);
	    		g.drawImage(LinkPose,75+550,355,this);
	    	}
	    	if(choosen2==5){
	    		g.drawImage(PokemonIcon,220+550,355,this);
	    		g.drawImage(PikachuPose,75+550,355,this);
	    	}
	    	if(choosen2==7){
	    		g.drawImage(CaptainIcon,210+550,355,this);
	    		g.drawImage(CaptainPose,75+550,345,this);
	    	}
	    	if(choosen2==8){
	    		g.drawImage(FoxIcon,210+550,355,this);
	    		g.drawImage(FoxPose,75+550,330,this);
	    	}
	    	if(choosen2==9){
	    		g.drawImage(SonicIcon,220+550,355,this);
	    		g.drawImage(SonicPose,75+550,355,this);
	    	}
	    	if(choosen2==10){
	    		g.drawImage(SonicIcon,220+550,355,this);
	    		g.drawImage(TailsPose,75+550,355,this);
	    	}

	    	if(Lives==1){
	    		g.drawImage(Num1,447,26,this);
	    	}
	    	if(Lives==2){
	    		g.drawImage(Num2,447,26,this);
	    	}
	    	if(Lives==3){
	    		g.drawImage(Num3,447,26,this);
	    	}
	    	if(Lives==4){
	    		g.drawImage(Num4,447,26,this);
	    	}
	    	if(Lives==5){
	    		g.drawImage(Num5,447,26,this);
	    	}
	    	if(Lives==6){
	    		g.drawImage(Num6,447,26,this);
	    	}
	    	if(Lives==7){
	    		g.drawImage(Num7,447,26,this);
	    	}
	    	if(Lives==8){
	    		g.drawImage(Num8,447,26,this);
	    	}
	    	if(Lives==9){
	    		g.drawImage(Num9,447,26,this);
	    	}
	    	if(Lives==10){
	    		g.drawImage(Num10,447,26,this);
	    	}
	    	if(choosen>0 && choosen2>0){
	    		g.drawImage(Ready,0,275,this);
	    	}
	    	g.drawImage(P1Circle,P1CircleX-25,P1CircleY-25,this);
	    	g.drawImage(P2Circle,P2CircleX-25,P2CircleY-25,this);
	    	//g.drawRect(498,38,22,30);
	    	//g.drawRect(425,38,22,30);
	    	//g.drawRect(520,26,344,50);
	    }
	    
	    	
	  }
}



