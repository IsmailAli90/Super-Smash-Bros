import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class MoveChar extends JFrame implements ActionListener,KeyListener{
	Timer myTimer;
	GamePanel game;

    public MoveChar() {
		super("Move the Box");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(900,650);

		myTimer = new Timer(10, this);	 // trigger every 10 ms
		myTimer.start();

		game = new GamePanel();
		add(game);
		addKeyListener(this);
		setResizable(false);
		setVisible(true);
    }

	public void actionPerformed(ActionEvent evt){
		if(game != null){
			game.refresh();
			game.repaint();
			game.update();
			game.collide();
		}
	}

    public void keyTyped(KeyEvent e) {}

    public void keyPressed(KeyEvent e) {
    	game.setKey(e.getKeyCode(),true);
    }

    public void keyReleased(KeyEvent e) {
    	game.setKey(e.getKeyCode(),false);
    }

    public static void main(String[] arguments) {
		MoveChar frame = new MoveChar();
    }
}

class GamePanel extends JPanel{
	int p1x,p1y,timer,timer2,jumpTimer,jumpTimer2,p1yy,choosen,choosen2,p2x,p2y,p2yy,i,hp,hp2,p2xx,p1xx;
	private boolean []keys;
	private Image back,Sonic,SW1,SW2,SW3,SW4,SW5,SW6,SW7,SW8,SJ,SJL,SF,SFL,SS1,SS2,SS3,SS4,SS5,SS6,SS7,SS8,SSL1,SSL2,SSL3,SSL4,SSL5,SSL6,SSL7,SSL8,P1C,P2C;
	private Image SWL1,SWL2,SWL3,SWL4,SWL5,SWL6,SWL7,SWL8,PokemonArenaBig,SPL1,SPL2,SPL3,SPL4,SP1,SP2,SP3,SP4;
	private Image Mario,MW1,MW2,MW3,MW4,MWR1,MWR2,MWR3,MWR4,MJ,MF,MJR,MFR,MP1,MP2,MP3,MP4,MP5,MPR1,MPR2,MPR3,MPR4,MPR5,MS1,MS2,MS3,MS4,MS5,MSR1,MSR2,MSR3,MSR4,MSR5;
	private Image Dk,DW1,DW2,DW3,DW4,DWL1,DWL2,DWL3,DWL4,DJ1,DJ2,DJ3,DJ4,DJ5,DJ6,DP1,DP2,DPL,DS1,DS2,DS3;
	private Image Captain,CW1,CW2,CW3,CW4,CW5,CW6,CWL1,CWL2,CWL3,CWL4,CWL5,CWL6,CJ,CF,CJL,CFL,CP1,CP2,CP3,CP4,CP5,CP6,CPL1,CPL2,CPL3,CPL4,CPL5,CPL6,CS1,CS2,CS3,CS4,CS5,CSL1,CSL2,CSL3,CSL4,CSL5;
	private Image Fox,FW1,FW2,FW3,FW4,FW5,FW6,FWL1,FWL2,FWL3,FWL4,FWL5,FWL6,FJ,FF,FJL,FFL,FP1,FP2,FP3,FP4,FPL1,FPL2,FPL3,FPL4,FS1,FS2,FS3,FS4,FSL1,FSL2,FSL3,FSL4;
	private Image Peach,PW1,PW2,PW3,PW4,PW5,PW6,PWL1,PWL2,PWL3,PWL4,PWL5,PWL6,PJ,PF,PJL,PFL,PP1,PP2,PP3,PP4,PPL1,PPL2,PPL3,PPL4,PS1,PS2,PS3,PS4,PS5,PS6,PS7,PS8,PSL1,PSL2,PSL3,PSL4,PSL5,PSL6,PSL7,PSL8;
	private Image Pikachu,PiW1,PiW2,PiW3,PiW4,PiWL1,PiWL2,PiWL3,PiWL4,PiJ1,PiJ2,PiJ3,PiJ4,PiF1,PiF2,PiF3,PiF4,PiP1,PiP2,PiP3,PiP4,PiPL1,PiPL2,PiPL3,PiPL4,PiL,PiS1,PiS2,PiS3,PiS4,PiS5,PiSL1,PiSL2,PiSL3,PiSL4,PiSL5;
	private Image Link,LW1,LW2,LW3,LW4,LW5,LW6,LWL1,LWL2,LWL3,LWL4,LWL5,LWL6,LJ,LF,LJL,LFL,LP1,LP2,LP3,LP4,LPL1,LPL2,LPL3,LPL4,LS1,LS2,LS3,LS4,LSL1,LSL2,LSL3,LSL4;
	private Image Luigi,LuW1,LuW2,LuW3,LuW4,LuW5,LuW6,LuW7,LuW8,LuWL1,LuWL2,LuWL3,LuWL4,LuWL5,LuWL6,LuWL7,LuWL8,LuJ,LuF1,LuF2,LuF3,LuF4,LuJL,LuFL1,LuFL2,LuFL3,LuFL4,LuP1,LuP2,LuP3,LuP4,LuPL1,LuPL2,LuPL3,LuPL4,LuS1,LuS2,LuS3,LuS4,LuS5,LuSL1,LuSL2,LuSL3,LuSL4,LuSL5;
	private Image Tails,TW1,TW2,TW3,TW4,TW5,TW6,TW7,TWL1,TWL2,TWL3,TWL4,TWL5,TWL6,TWL7,TJ,TF,TJL,TFL,TP1,TP2,TP3,TP4,TP5,TP6,TPL1,TPL2,TPL3,TPL4,TPL5,TPL6,TS1,TS2,TS3,TS4,TS5,TSL1,TSL2,TSL3,TSL4,TSL5;
	private boolean right,right2,left,left2,up,up2,onGround,onGround2,basic,basic2,checkCollide,checkCollide2,knockback,knockback2,special,special2;

	public GamePanel(){
		keys = new boolean[KeyEvent.KEY_LAST+1];
		back = new ImageIcon("OuterSpace.jpg").getImage();
		
		P1C = new ImageIcon("P1Circle.png").getImage();
		P1C = P1C.getScaledInstance(20,20,Image.SCALE_SMOOTH);
		P2C = new ImageIcon("P2Circle.png").getImage();
		P2C = P2C.getScaledInstance(20,20,Image.SCALE_SMOOTH);
		Tails = new ImageIcon("Tails.png").getImage();
		TW1 = new ImageIcon("TW001.png").getImage();
		TW2 = new ImageIcon("TW002.png").getImage();
		TW3 = new ImageIcon("TW003.png").getImage();
		TW4 = new ImageIcon("TW004.png").getImage();
		TW5 = new ImageIcon("TW005.png").getImage();
		TW6 = new ImageIcon("TW006.png").getImage();
		TW7 = new ImageIcon("TW007.png").getImage();
		
		TS1 = new ImageIcon("TS001.png").getImage();
		TS2 = new ImageIcon("TS002.png").getImage();
		TS3 = new ImageIcon("TS003.png").getImage();
		TS4 = new ImageIcon("TS004.png").getImage();
		TS5 = new ImageIcon("TS005.png").getImage();
		
		FP1 = new ImageIcon("FoxP001.png").getImage();
		FP2 = new ImageIcon("FoxP002.png").getImage();
		FP3 = new ImageIcon("FoxP003.png").getImage();
		FP4 = new ImageIcon("FoxP004.png").getImage();
		
		TP1 = new ImageIcon("TP001.png").getImage();
		TP2 = new ImageIcon("TP002.png").getImage();
		TP3 = new ImageIcon("TP003.png").getImage();
		TP4 = new ImageIcon("TP004.png").getImage();
		TP5 = new ImageIcon("TP005.png").getImage();
		TP6 = new ImageIcon("TP006.png").getImage();
		
		LP1 = new ImageIcon("LP001.png").getImage();
		LP2 = new ImageIcon("LP002.png").getImage();
		LP3 = new ImageIcon("LP003.png").getImage();
		LP4 = new ImageIcon("LP004.png").getImage();
		
		PP1 = new ImageIcon("PP001.png").getImage();
		PP2 = new ImageIcon("PP002.png").getImage();
		PP3 = new ImageIcon("PP003.png").getImage();
		PP4 = new ImageIcon("PP004.png").getImage();
		
		DP1 = new ImageIcon("DP1.png").getImage();
		DP2 = new ImageIcon("DP2.png").getImage();
		DPL = new ImageIcon("DPL.png").getImage();
		
		PPL1 = new ImageIcon("PPL1.png").getImage();
		PPL2 = new ImageIcon("PPL2.png").getImage();
		PPL3 = new ImageIcon("PPL3.png").getImage();
		PPL4 = new ImageIcon("PPL4.png").getImage();
		
		FPL1 = new ImageIcon("FoxPL004.png").getImage();
		FPL2 = new ImageIcon("FoxPL003.png").getImage();
		FPL3 = new ImageIcon("FoxPL002.png").getImage();
		FPL4 = new ImageIcon("FoxPL001.png").getImage();
		
		MP1 = new ImageIcon("marioSheet026.png").getImage();
		MP2 = new ImageIcon("marioSheet027.png").getImage();
		MP3 = new ImageIcon("marioSheet028.png").getImage();
		MP4 = new ImageIcon("marioSheet029.png").getImage();
		MP5 = new ImageIcon("marioSheet030.png").getImage();
		
		MS1 = new ImageIcon("marioSheet074.png").getImage();
		MS2 = new ImageIcon("marioSheet075.png").getImage();
		MS3 = new ImageIcon("marioSheet076.png").getImage();
		MS4 = new ImageIcon("marioSheet077.png").getImage();
		MS5 = new ImageIcon("marioSheet078.png").getImage();
		
		MPR1 = new ImageIcon("MPR1.png").getImage();
		MPR2 = new ImageIcon("MPR2.png").getImage();
		MPR3 = new ImageIcon("MPR3.png").getImage();
		MPR4 = new ImageIcon("MPR4.png").getImage();
		MPR5 = new ImageIcon("MPR5.png").getImage();
		
		MSR1 = new ImageIcon("MSR1.png").getImage();
		MSR2 = new ImageIcon("MSR2.png").getImage();
		MSR3 = new ImageIcon("MSR3.png").getImage();
		MSR4 = new ImageIcon("MSR4.png").getImage();
		MSR5 = new ImageIcon("MSR5.png").getImage();
		
		LPL1 = new ImageIcon("LPL004.png").getImage();
		LPL2 = new ImageIcon("LPL003.png").getImage();
		LPL3 = new ImageIcon("LPL002.png").getImage();
		LPL4 = new ImageIcon("LPL001.png").getImage();
		
		TSL1 = new ImageIcon("TPL005.png").getImage();
		TSL2 = new ImageIcon("TPL004.png").getImage();
		TSL3 = new ImageIcon("TPL003.png").getImage();
		TSL4 = new ImageIcon("TPL002.png").getImage();
		TSL5 = new ImageIcon("TPL001.png").getImage();
	
		TPL1 = new ImageIcon("TPL001.png").getImage();
		TPL2 = new ImageIcon("TPL002.png").getImage();
		TPL3 = new ImageIcon("TPL003.png").getImage();
		TPL4 = new ImageIcon("TPL004.png").getImage();
		TPL5 = new ImageIcon("TPL005.png").getImage();
		TPL6 = new ImageIcon("TPL006.png").getImage();
	
		
		Luigi = new ImageIcon("Luigi.png").getImage();
		LuW1 = new ImageIcon("LuW001.png").getImage();
		LuW2 = new ImageIcon("LuW002.png").getImage();
		LuW3 = new ImageIcon("LuW003.png").getImage();
		LuW4 = new ImageIcon("LuW004.png").getImage();
		LuW5 = new ImageIcon("LuW005.png").getImage();
		LuW6 = new ImageIcon("LuW006.png").getImage();
		LuW7 = new ImageIcon("LuW007.png").getImage();
		LuW8 = new ImageIcon("LuW008.png").getImage();
		
		Pikachu = new ImageIcon("Pikachu.png").getImage();
		PiP1 = new ImageIcon("PiP2001.png").getImage();
		PiP2 = new ImageIcon("PiP2002.png").getImage();
		PiP3 = new ImageIcon("PiP003.png").getImage();
		PiP4 = new ImageIcon("PiP002.png").getImage();
		
		PiS1 = new ImageIcon("PiP2001.png").getImage();
		PiS2 = new ImageIcon("PiP2002.png").getImage();
		PiS3 = new ImageIcon("PiS001.png").getImage();
		PiS4 = new ImageIcon("PiS002.png").getImage();
		PiS5 = new ImageIcon("PiS003.png").getImage();
		
		PiSL1 = new ImageIcon("PiPL1.png").getImage();
		PiSL2 = new ImageIcon("PiPL2.png").getImage();
		PiSL3 = new ImageIcon("PiSL003.png").getImage();
		PiSL4 = new ImageIcon("PiSL002.png").getImage();
		PiSL5 = new ImageIcon("PiSL001.png").getImage();
		
		PiPL1 = new ImageIcon("PiPL1.png").getImage();
		PiPL2 = new ImageIcon("PiPL2.png").getImage();
		PiPL3 = new ImageIcon("PiPL001.png").getImage();
		PiPL4 = new ImageIcon("PiPL002.png").getImage();
		
		PiW1 = new ImageIcon("PiW001.png").getImage();
		PiW2 = new ImageIcon("PiW002.png").getImage();
		PiW3 = new ImageIcon("PiW003.png").getImage();
		PiW4 = new ImageIcon("PiW004.png").getImage();
		
		Link = new ImageIcon("Link.png").getImage();
		LW1 = new ImageIcon("LW001.png").getImage();
		LW2 = new ImageIcon("LW002.png").getImage();
		LW3 = new ImageIcon("LW003.png").getImage();
		LW4 = new ImageIcon("LW004.png").getImage();
		LW5 = new ImageIcon("LW005.png").getImage();
		LW6 = new ImageIcon("LW006.png").getImage();
		
		Peach = new ImageIcon("Peach.png").getImage();
		PW1 = new ImageIcon("PW001.png").getImage();
		PW2 = new ImageIcon("PW002.png").getImage();
		PW3 = new ImageIcon("PW003.png").getImage();
		PW4 = new ImageIcon("PW004.png").getImage();
		PW5 = new ImageIcon("PW005.png").getImage();
		PW6 = new ImageIcon("PW006.png").getImage();
		
		LuS1 = new ImageIcon("LuS001.png").getImage();
		LuS2 = new ImageIcon("LuS002.png").getImage();
		LuS3 = new ImageIcon("LuS003.png").getImage();
		LuS4 = new ImageIcon("LuS004.png").getImage();
		LuS5 = new ImageIcon("LuS005.png").getImage();
		
		LuSL1 = new ImageIcon("LuSL005.png").getImage();
		LuSL2 = new ImageIcon("LuSL004.png").getImage();
		LuSL3 = new ImageIcon("LuSL003.png").getImage();
		LuSL4 = new ImageIcon("LuSL002.png").getImage();
		LuSL5 = new ImageIcon("LuSL001.png").getImage();
		
		Fox = new ImageIcon("Fox.png").getImage();
		FW1 = new ImageIcon("FoxWalk001.png").getImage();
		FW2 = new ImageIcon("FoxWalk002.png").getImage();
		FW3 = new ImageIcon("FoxWalk003.png").getImage();
		FW4 = new ImageIcon("FoxWalk004.png").getImage();
		FW5 = new ImageIcon("FoxWalk005.png").getImage();
		FW6 = new ImageIcon("FoxWalk006.png").getImage();
		
		Captain = new ImageIcon("CaptainSheet003.png").getImage();
		CW1 = new ImageIcon("CaptainSheet007.png").getImage();
		CW2 = new ImageIcon("CaptainSheet008.png").getImage();
		CW3 = new ImageIcon("CaptainSheet009.png").getImage();
		CW4 = new ImageIcon("CaptainSheet010.png").getImage();
		CW5 = new ImageIcon("CaptainSheet011.png").getImage();
		CW6 = new ImageIcon("CaptainSheet012.png").getImage();
		
		CS1 = new ImageIcon("CSL1.png").getImage();
		CS2 = new ImageIcon("CSL2.png").getImage();
		CS3 = new ImageIcon("CaptainSheet030.png").getImage();
		CS4 = new ImageIcon("CaptainSheet005.png").getImage();
		CS5 = new ImageIcon("CaptainSheet006.png").getImage();
		
		LS1 = new ImageIcon("LS1.png").getImage();
		LS2 = new ImageIcon("LS001.png").getImage();
		LS3 = new ImageIcon("LS002.png").getImage();
		LS4 = new ImageIcon("LS004.png").getImage();
		
		LSL1 = new ImageIcon("LSL1.png").getImage();
		LSL2 = new ImageIcon("LSL004.png").getImage();
		LSL3 = new ImageIcon("LSL003.png").getImage();
		LSL4 = new ImageIcon("LSL001.png").getImage();
		
		PS1 = new ImageIcon("PS001.png").getImage();
		PS2 = new ImageIcon("PS002.png").getImage();
		PS3 = new ImageIcon("PS008.png").getImage();
		PS4 = new ImageIcon("PS003.png").getImage();
		PS5 = new ImageIcon("PS004.png").getImage();
		PS6 = new ImageIcon("PS005.png").getImage();
		PS7 = new ImageIcon("PS006.png").getImage();
		PS8 = new ImageIcon("PS007.png").getImage();
		
		PSL1 = new ImageIcon("PSL1.png").getImage();
		PSL2 = new ImageIcon("PSL2.png").getImage();
		PSL3 = new ImageIcon("PSL3.png").getImage();
		PSL4 = new ImageIcon("PSL4.png").getImage();
		PSL5 = new ImageIcon("PSL5.png").getImage();
		PSL6 = new ImageIcon("PSL6.png").getImage();
		PSL7 = new ImageIcon("PSL7.png").getImage();
		PSL8 = new ImageIcon("PSL8.png").getImage();
		
		SS1 = new ImageIcon("Sonic087.png").getImage();
		SS2 = new ImageIcon("Sonic088.png").getImage();
		SS3 = new ImageIcon("Sonic089.png").getImage();
		SS4 = new ImageIcon("Sonic090.png").getImage();
		SS5 = new ImageIcon("Sonic091.png").getImage();
		SS6 = new ImageIcon("Sonic092.png").getImage();
		SS7 = new ImageIcon("Sonic093.png").getImage();
		SS8 = new ImageIcon("Sonic094.png").getImage();
		
		SSL1 = new ImageIcon("SSL1.png").getImage();
		SSL2 = new ImageIcon("SSL2.png").getImage();
		SSL3 = new ImageIcon("SSL3.png").getImage();
		SSL4 = new ImageIcon("SSL4.png").getImage();
		SSL5 = new ImageIcon("SSL5.png").getImage();
		SSL6 = new ImageIcon("SSL6.png").getImage();
		SSL7 = new ImageIcon("SSL7.png").getImage();
		SSL8 = new ImageIcon("SSL8.png").getImage();
		
		FSL1 = new ImageIcon("FSL005.png").getImage();
		FSL2 = new ImageIcon("FSL004.png").getImage();
		FSL3 = new ImageIcon("FSL003.png").getImage();
		FSL4 = new ImageIcon("FSL002.png").getImage();
		
		FS1 = new ImageIcon("FS001.png").getImage();
		FS2 = new ImageIcon("FS002.png").getImage();
		FS3 = new ImageIcon("FS003.png").getImage();
		FS4 = new ImageIcon("FS004.png").getImage();
		
		CSL1 = new ImageIcon("CaptainSheet028.png").getImage();
		CSL2 = new ImageIcon("CaptainSheet029.png").getImage();
		CSL3 = new ImageIcon("CSL3.png").getImage();
		CSL4 = new ImageIcon("CSL4.png").getImage();
		CSL5 = new ImageIcon("CSL5.png").getImage();
		
		CWL1 = new ImageIcon("CWL1.png").getImage();
		CWL2 = new ImageIcon("CWL2.png").getImage();
		CWL3 = new ImageIcon("CWL3.png").getImage();
		CWL4 = new ImageIcon("CWL4.png").getImage();
		CWL5 = new ImageIcon("CWL5.png").getImage();
		CWL6 = new ImageIcon("CWL6.png").getImage();
		
		CP1 = new ImageIcon("CaptainSheet031.png").getImage();
		CP2 = new ImageIcon("CaptainSheet032.png").getImage();
		CP3 = new ImageIcon("CaptainSheet033.png").getImage();
		CP4 = new ImageIcon("CaptainSheet034.png").getImage();
		CP5 = new ImageIcon("CaptainSheet035.png").getImage();
		CP6 = new ImageIcon("CPR6.png").getImage();
		
		
		Sonic = new ImageIcon("Sonic001.png").getImage();
		SW1 = new ImageIcon("Sonic036.png").getImage();
		SW2 = new ImageIcon("Sonic037.png").getImage();
		SW3 = new ImageIcon("Sonic038.png").getImage();
		SW4 = new ImageIcon("Sonic039.png").getImage();
		SW5 = new ImageIcon("Sonic040.png").getImage();
		SW6 = new ImageIcon("Sonic041.png").getImage();
		SW7 = new ImageIcon("Sonic042.png").getImage();
		
		SP1 = new ImageIcon("Sonic081.png").getImage();
		SP2 = new ImageIcon("Sonic082.png").getImage();
		SP3 = new ImageIcon("Sonic083.png").getImage();
		SP4 = new ImageIcon("Sonic084.png").getImage();
		
		SPL1 = new ImageIcon("SPL1.png").getImage();
		SPL2 = new ImageIcon("SPL2.png").getImage();
		SPL3 = new ImageIcon("SPL3.png").getImage();
		SPL4 = new ImageIcon("SPL4.png").getImage();
		
		Mario = new ImageIcon("marioSheet083.png").getImage();
		MW1 = new ImageIcon("marioSheet009.png").getImage();
		MW2 = new ImageIcon("marioSheet010.png").getImage();
		MW3 = new ImageIcon("marioSheet011.png").getImage();
		MW4 = new ImageIcon("marioSheet012.png").getImage();
		
		Dk= new ImageIcon("DonkeyKongSheet022.png").getImage();
		DW1 = new ImageIcon("DW1.png").getImage();
		DW2 = new ImageIcon("DW2.png").getImage();
		DW3 = new ImageIcon("DW3.png").getImage();
		DW4 = new ImageIcon("DW4.png").getImage();
		
		TWL1 = new ImageIcon("TWL1.png").getImage();
		TWL2 = new ImageIcon("TWL2.png").getImage();
		TWL3 = new ImageIcon("TWL3.png").getImage();
		TWL4 = new ImageIcon("TWL4.png").getImage();
		TWL5 = new ImageIcon("TWL5.png").getImage();
		TWL6 = new ImageIcon("TWL6.png").getImage();
		TWL7 = new ImageIcon("TWL7.png").getImage();
		
		SWL1 = new ImageIcon("SonicWL1.png").getImage();
		SWL2 = new ImageIcon("SonicWL2.png").getImage();
		SWL3 = new ImageIcon("SonicWL3.png").getImage();
		SWL4 = new ImageIcon("SonicWL4.png").getImage();
		SWL5 = new ImageIcon("SonicWL5.png").getImage();
		SWL6 = new ImageIcon("SonicWL6.png").getImage();
		SWL7 = new ImageIcon("SonicWL7.png").getImage();
		
		PiWL1 = new ImageIcon("PiWL1.png").getImage();
		PiWL2 = new ImageIcon("PiWL2.png").getImage();
		PiWL3 = new ImageIcon("PiWL3.png").getImage();
		PiWL4 = new ImageIcon("PiWL4.png").getImage();
		PiL = new ImageIcon("PiL.png").getImage();
		
		LuWL1 = new ImageIcon("LuWL1.png").getImage();
		LuWL2 = new ImageIcon("LuWL2.png").getImage();
		LuWL3 = new ImageIcon("LuWL3.png").getImage();
		LuWL4 = new ImageIcon("LuWL4.png").getImage();
		LuWL5 = new ImageIcon("LuWL5.png").getImage();
		LuWL6 = new ImageIcon("LuWL6.png").getImage();
		LuWL7 = new ImageIcon("LuWL7.png").getImage();
		LuWL8 = new ImageIcon("LuWL8.png").getImage();
		
		
		LWL1 = new ImageIcon("LWL1.png").getImage();
		LWL2 = new ImageIcon("LWL2.png").getImage();
		LWL3 = new ImageIcon("LWL3.png").getImage();
		LWL4 = new ImageIcon("LWL4.png").getImage();
		LWL5 = new ImageIcon("LWL5.png").getImage();
		LWL6 = new ImageIcon("LWL6.png").getImage();
		
		PWL1 = new ImageIcon("PWL1.png").getImage();
		PWL2 = new ImageIcon("PWL2.png").getImage();
		PWL3 = new ImageIcon("PWL3.png").getImage();
		PWL4 = new ImageIcon("PWL4.png").getImage();
		PWL5 = new ImageIcon("PWL5.png").getImage();
		PWL6 = new ImageIcon("PWL6.png").getImage();
		
		CPL1 = new ImageIcon("CPL1.png").getImage();
		CPL2 = new ImageIcon("CPL2.png").getImage();
		CPL3 = new ImageIcon("CPL3.png").getImage();
		CPL4 = new ImageIcon("CPL4.png").getImage();
		CPL5 = new ImageIcon("CPL5.png").getImage();
		CPL6 = new ImageIcon("CaptainSheet029.png").getImage();
		
		
		FWL1 = new ImageIcon("FWL1.png").getImage();
		FWL2 = new ImageIcon("FWL2.png").getImage();
		FWL3 = new ImageIcon("FWL3.png").getImage();
		FWL4 = new ImageIcon("FWL4.png").getImage();
		FWL5 = new ImageIcon("FWL5.png").getImage();
		FWL6 = new ImageIcon("FWL6.png").getImage();
		
		TJL = new ImageIcon("TJL.png").getImage();
		TFL = new ImageIcon("TFL.png").getImage();
		TJ = new ImageIcon("TJ.png").getImage();
		TF = new ImageIcon("TF.png").getImage();
		
		PJL = new ImageIcon("PJL.png").getImage();
		PFL = new ImageIcon("PFL.png").getImage();
		PJ = new ImageIcon("PJ.png").getImage();
		PF = new ImageIcon("PF.png").getImage();
		
		LJL = new ImageIcon("LJL.png").getImage();
		LFL = new ImageIcon("LFL.png").getImage();
		LJ = new ImageIcon("LJ.png").getImage();
		LF = new ImageIcon("LF.png").getImage();
		
		LuJL = new ImageIcon("LuJL.png").getImage();
		LuFL1 = new ImageIcon("LuFL1.png").getImage();
		LuFL2 = new ImageIcon("LuFL2.png").getImage();
		LuFL3 = new ImageIcon("LuFL3.png").getImage();
		LuFL4 = new ImageIcon("LuFL4.png").getImage();
		LuJ = new ImageIcon("LuJ.png").getImage();
		LuF1 = new ImageIcon("LuF1.png").getImage();
		LuF2 = new ImageIcon("LuF2.png").getImage();
		LuF3 = new ImageIcon("LuF3.png").getImage();
		LuF4 = new ImageIcon("LuF4.png").getImage();
		
		CJL = new ImageIcon("CJL.png").getImage();
		CFL = new ImageIcon("CFL.png").getImage();
		CJ = new ImageIcon("CaptainSheet004.png").getImage();
		CF = new ImageIcon("CaptainSheet026.png").getImage();
		
		FJL = new ImageIcon("FJL.png").getImage();
		FFL = new ImageIcon("FFL.png").getImage();
		FJ = new ImageIcon("FJ.png").getImage();
		FF = new ImageIcon("FF.png").getImage();
		
		MWR1 = new ImageIcon("MarioWR1.png").getImage();
		MWR2 = new ImageIcon("MarioWR2.png").getImage();
		MWR3 = new ImageIcon("MarioWR3.png").getImage();
		MWR4 = new ImageIcon("MarioWR4.png").getImage();
		
		DWL1 = new ImageIcon("DWL.png").getImage();
		DWL2 = new ImageIcon("DWL2.png").getImage();
		DWL3 = new ImageIcon("DWL3.png").getImage();
		DWL4 = new ImageIcon("DWL4.png").getImage();
		
		SJ = new ImageIcon("Sonic076.png").getImage();
		SF = new ImageIcon("Sonic080.png").getImage();
		SJL = new ImageIcon("SJL.png").getImage();
		SFL = new ImageIcon("SFL.png").getImage();
		
		MJR = new ImageIcon("MJR.png").getImage();
		MFR = new ImageIcon("MFR.png").getImage();
		MJ = new ImageIcon("marioSheet021.png").getImage();
		MF = new ImageIcon("marioSheet024.png").getImage();
		
		DJ4 = new ImageIcon("DonkeyKongSheet050.png").getImage();
		DJ5 = new ImageIcon("DonkeyKongSheet051.png").getImage();
		DJ6 = new ImageIcon("DonkeyKongSheet052.png").getImage();
		DJ1 = new ImageIcon("DonkeyKongSheet053.png").getImage();
		DJ2 = new ImageIcon("DonkeyKongSheet054.png").getImage();
		DJ3 = new ImageIcon("DonkeyKongSheet055.png").getImage();
		
		DS1 = new ImageIcon("DS001.png").getImage();
		DS2 = new ImageIcon("DS003.png").getImage();
		DS3 = new ImageIcon("DonkeyKongSheet053.png").getImage();
		
		PiJ1 = new ImageIcon("PiJ1.png").getImage();
		PiJ2 = new ImageIcon("PiJ2.png").getImage();
		PiJ3 = new ImageIcon("PiJ3.png").getImage();
		PiJ4 = new ImageIcon("PiJ4.png").getImage();
		
		PiF1 = new ImageIcon("PiF1.png").getImage();
		PiF2 = new ImageIcon("PiF2.png").getImage();
		PiF3 = new ImageIcon("PiF3.png").getImage();
		PiF4 = new ImageIcon("PiF4.png").getImage();
		
		LuP1= new ImageIcon("LuP001.png").getImage();
		LuP2= new ImageIcon("LuP002.png").getImage();
		LuP3= new ImageIcon("LuP003.png").getImage();
		LuP4= new ImageIcon("LuP004.png").getImage();
		
		LuPL1= new ImageIcon("LuPL004.png").getImage();
		LuPL2= new ImageIcon("LuPL003.png").getImage();
		LuPL3= new ImageIcon("LuPL002.png").getImage();
		LuPL4= new ImageIcon("LuPL001.png").getImage();
		
		Pikachu = Pikachu.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		PiW1 = PiW1.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		PiW2 = PiW2.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		PiW3 = PiW3.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		PiW4 = PiW4.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		
		PiL = PiL.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		PiWL1 = PiWL1.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		PiWL2 = PiWL2.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		PiWL3 = PiWL3.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		PiWL4 = PiWL4.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		
		Tails = Tails.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		TW1 = TW1.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		TW2 = TW2.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		TW3 = TW3.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		TW4 = TW4.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		TW5 = TW5.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		TW6 = TW6.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		TW7 = TW7.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		
		TWL1 = TWL1.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		TWL2 = TWL2.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		TWL3 = TWL3.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		TWL4 = TWL4.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		TWL5 = TWL5.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		TWL6 = TWL6.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		TWL7 = TWL7.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		
		DP1 = DP1.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		DP2 = DP2.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		DPL = DPL.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		
		DS1 = DS1.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		DS2 = DS2.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		DS3 = DS3.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		
		
		LP1 = LP1.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LP2 = LP2.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LP3 = LP3.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		LP4 = LP4.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		
		LS1 = LS1.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		LS2 = LS2.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		LS3 = LS3.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		LS4 = LS4.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		
		FS1 = FS1.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		FS2 = FS2.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		FS3 = FS3.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		FS4 = FS4.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		
		FP1 = FP1.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		FP2 = FP2.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		FP3 = FP3.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		FP4 = FP4.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		
		PS1 = PS1.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		PS2 = PS2.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		PS3 = PS3.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		PS4 = PS4.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		PS5 = PS5.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		PS6 = PS6.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		PS7 = PS7.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		PS8 = PS8.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		
		PP1 = PP1.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		PP2 = PP2.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		PP3 = PP3.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		PP4 = PP4.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		
		TS1 = TS1.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		TS2 = TS2.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		TS3 = TS3.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		TS4 = TS4.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		TS5 = TS5.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		
		TP1 = TP1.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		TP2 = TP2.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		TP3 = TP3.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		TP4 = TP4.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		TP5 = TP5.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		TP6 = TP6.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		
		FSL1 = FSL1.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		FSL2 = FSL2.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		FSL3 = FSL3.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		FSL4 = FSL4.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		
		FPL1 = FPL1.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		FPL2 = FPL2.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		FPL3 = FPL3.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		FPL4 = FPL4.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		
		TSL1 = TSL1.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		TSL2 = TSL2.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		TSL3 = TSL3.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		TSL4 = TSL4.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		TSL5 = TSL5.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		
		
		TPL1 = TPL1.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		TPL2 = TPL2.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		TPL3 = TPL3.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		TPL4 = TPL4.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		TPL5 = TPL5.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		
		PSL1 = PSL1.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		PSL2 = PSL2.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		PSL3 = PSL3.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		PSL4 = PSL4.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		PSL5 = PSL5.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		PSL6 = PSL6.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		PSL7 = PSL7.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		PSL8 = PSL8.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		
		PPL1 = PPL1.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		PPL2 = PPL2.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		PPL3 = PPL3.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		PPL4 = PPL4.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		
		LSL1 = LSL1.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		LSL2 = LSL2.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		LSL3 = LSL3.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		LSL4 = LSL4.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		
		LPL1 = LPL1.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LPL2 = LPL2.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LPL3 = LPL3.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		LPL4 = LPL4.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		
		
		
		Luigi = Luigi.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LuW1 = LuW1.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LuW2 = LuW2.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LuW3 = LuW3.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LuW4 = LuW4.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LuW5 = LuW5.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LuW6 = LuW6.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		
		Link = Link.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LW1 = LW1.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LW2 = LW2.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LW3 = LW3.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LW4 = LW4.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LW5 = LW5.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LW6 = LW6.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		
		LWL1 = LWL1.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LWL2 = LWL2.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LWL3 = LWL3.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LWL4 = LWL4.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LWL5 = LWL5.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LWL6 = LWL6.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		
		Peach = Peach.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		PW1 = PW1.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		PW2 = PW2.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		PW3 = PW3.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		PW4 = PW4.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		PW5 = PW5.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		PW6 = PW6.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		
		PWL1 = PWL1.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		PWL2 = PWL2.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		PWL3 = PWL3.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		PWL4 = PWL4.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		PWL5 = PWL5.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		PWL6 = PWL6.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		
		Fox = Fox.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		FW1 = FW1.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		FW2 = FW2.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		FW3 = FW3.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		FW4 = FW4.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		FW5 = FW5.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		FW6 = FW6.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		
		FWL1 = FWL1.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		FWL2 = FWL2.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		FWL3 = FWL3.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		FWL4 = FWL4.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		FWL5 = FWL5.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		FWL6 = FWL6.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		
		Captain = Captain.getScaledInstance(30,60,Image.SCALE_SMOOTH);
		CW1 = CW1.getScaledInstance(30,60,Image.SCALE_SMOOTH);
		CW2 = CW2.getScaledInstance(30,60,Image.SCALE_SMOOTH);
		CW3 = CW3.getScaledInstance(30,60,Image.SCALE_SMOOTH);
		CW4 = CW4.getScaledInstance(30,60,Image.SCALE_SMOOTH);
		CW5 = CW5.getScaledInstance(30,60,Image.SCALE_SMOOTH);
		CW6 = CW6.getScaledInstance(30,60,Image.SCALE_SMOOTH);
		
		CS1 = CS1.getScaledInstance(50,60,Image.SCALE_SMOOTH);
		CS2 = CS2.getScaledInstance(50,60,Image.SCALE_SMOOTH);
		CS3 = CS3.getScaledInstance(50,60,Image.SCALE_SMOOTH);
		CS4 = CS4.getScaledInstance(50,60,Image.SCALE_SMOOTH);
		CS5 = CS5.getScaledInstance(50,60,Image.SCALE_SMOOTH);
		
		CP1 = CP1.getScaledInstance(50,60,Image.SCALE_SMOOTH);
		CP2 = CP2.getScaledInstance(50,60,Image.SCALE_SMOOTH);
		CP3 = CP3.getScaledInstance(50,60,Image.SCALE_SMOOTH);
		CP4 = CP4.getScaledInstance(50,60,Image.SCALE_SMOOTH);
		CP5 = CP5.getScaledInstance(50,60,Image.SCALE_SMOOTH);
		CP6 = CP6.getScaledInstance(50,60,Image.SCALE_SMOOTH);
		
		CSL1 = CSL1.getScaledInstance(50,60,Image.SCALE_SMOOTH);
		CSL2 = CSL2.getScaledInstance(50,60,Image.SCALE_SMOOTH);
		CSL3 = CSL3.getScaledInstance(50,60,Image.SCALE_SMOOTH);
		CSL4 = CSL4.getScaledInstance(50,60,Image.SCALE_SMOOTH);
		CSL5 = CSL5.getScaledInstance(50,60,Image.SCALE_SMOOTH);
		
		CPL1 = CPL1.getScaledInstance(30,60,Image.SCALE_SMOOTH);
		CPL2 = CPL2.getScaledInstance(30,60,Image.SCALE_SMOOTH);
		CPL3 = CPL3.getScaledInstance(30,60,Image.SCALE_SMOOTH);
		CPL4 = CPL4.getScaledInstance(30,60,Image.SCALE_SMOOTH);
		CPL5 = CPL5.getScaledInstance(30,60,Image.SCALE_SMOOTH);
		CPL6 = CPL6.getScaledInstance(50,60,Image.SCALE_SMOOTH);
		
		
		
		CWL1 = CWL1.getScaledInstance(30,60,Image.SCALE_SMOOTH);
		CWL2 = CWL2.getScaledInstance(30,60,Image.SCALE_SMOOTH);
		CWL3 = CWL3.getScaledInstance(30,60,Image.SCALE_SMOOTH);
		CWL4 = CWL4.getScaledInstance(30,60,Image.SCALE_SMOOTH);
		CWL5 = CWL5.getScaledInstance(30,60,Image.SCALE_SMOOTH);
		CWL6 = CWL6.getScaledInstance(50,60,Image.SCALE_SMOOTH);
		
		SW1 = SW1.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		SW2 = SW2.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		SW3 = SW3.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		SW4 = SW4.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		
		SS1 = SS1.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		SS2 = SS2.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		SS3 = SS3.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		SS4 = SS4.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		SS5 = SS5.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		SS6 = SS6.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		SS7 = SS7.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		SS8 = SS8.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		
		SP1 = SP1.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		SP2 = SP2.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		SP3 = SP3.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		SP4 = SP4.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		
		SSL1 = SSL1.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		SSL2 = SSL2.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		SSL3 = SSL3.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		SSL4 = SSL4.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		SSL5 = SSL5.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		SSL6 = SSL6.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		SSL7 = SSL7.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		SSL8 = SSL8.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		
		SPL1 = SPL1.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		SPL2 = SPL2.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		SPL3 = SPL3.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		SPL4 = SPL4.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		
		SW5 = SW5.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		SW6 = SW6.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		SW7 = SW7.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		
		SWL1 = SWL1.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		SWL2 = SWL2.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		SWL3 = SWL3.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		SWL4 = SWL4.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		SWL5 = SWL5.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		SWL6 = SWL6.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		SWL7 = SWL7.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		
		LuWL1 = LuWL1.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LuWL2 = LuWL2.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LuWL3 = LuWL3.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LuWL4 = LuWL4.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LuWL5 = LuWL5.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LuWL6 = LuWL6.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LuWL7 = LuWL7.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LuWL8 = LuWL8.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		
		PiJ1  = PiJ1.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		PiJ2  = PiJ2.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		PiJ3  = PiJ3.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		PiJ4  = PiJ4.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		
		PiS1  = PiS1.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		PiS2  = PiS2.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		PiS3  = PiS3.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		PiS4  = PiS4.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		PiS5  = PiS5.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		
		PiP1  = PiP1.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		PiP2  = PiP2.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		PiP3  = PiP3.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		PiP4  = PiP4.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		
		PiSL1  = PiSL1.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		PiSL2  = PiSL2.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		PiSL3  = PiSL3.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		PiSL4  = PiSL4.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		PiSL5  = PiSL5.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		
		PiPL1  = PiPL1.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		PiPL2  = PiPL2.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		PiPL3  = PiPL3.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		PiPL4  = PiPL4.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		
		MS1  = MS1.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		MS2  = MS2.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		MS3  = MS3.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		MS4  = MS4.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		MS5  = MS5.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		
		MP1  = MP1.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		MP2  = MP2.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		MP3  = MP3.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		MP4  = MP4.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		MP5  = MP5.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		
		
		PiF1  = PiF1.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		PiF2  = PiF2.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		PiF3  = PiF3.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		PiF4  = PiF4.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		
		LuJ  = LuJ.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LuF1  = LuF1.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LuF2 = LuF2.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LuF3  = LuF3.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LuF4  = LuF4.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LuFL1 = LuFL1.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LuFL2 = LuFL2.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LuFL3 = LuFL3.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LuFL4 = LuFL4.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LuJL = LuJL.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		
		LuP1  = LuP1.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LuP2  = LuP2.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		LuP3  = LuP3.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		LuP4  = LuP4.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		
		LuS1  = LuS1.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LuS2  = LuS2.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		LuS3  = LuS3.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		LuS4  = LuS4.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		LuS5  = LuS5.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		
		LuSL1  = LuSL1.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LuSL2  = LuSL2.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		LuSL3  = LuSL3.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		LuSL4  = LuSL4.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		LuSL5  = LuSL5.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		
		LuPL1  = LuPL1.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LuPL2  = LuPL2.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		LuPL3  = LuPL3.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		LuPL4  = LuPL4.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		
		LJ  = LJ.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LF  = LF.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LFL = LFL.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		LJL = LJL.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		
		PJ  = PJ.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		PF  = PF.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		PFL = PFL.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		PJL = PJL.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		
		FJ  = FJ.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		FF  = FF.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		FFL = FFL.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		FJL = FJL.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		
		CJ = CJ.getScaledInstance(30,60,Image.SCALE_SMOOTH);
		CF = CF.getScaledInstance(30,60,Image.SCALE_SMOOTH);
		CFL = CFL.getScaledInstance(30,60,Image.SCALE_SMOOTH);
		CJL = CJL.getScaledInstance(30,60,Image.SCALE_SMOOTH);
		
		SJ = SJ.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		SFL = SFL.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		SJ = SJ.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		SJL = SJL.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		
		Mario = Mario.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		MW1 = MW1.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		MW2 = MW2.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		MW3 = MW3.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		MW4 = MW4.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		
		MWR1 = MWR1.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		MWR2 = MWR2.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		MWR3 = MWR3.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		MWR4 = MWR4.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		
		MPR1 = MPR1.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		MPR2 = MPR2.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		MPR3 = MPR3.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		MPR4 = MPR4.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		MPR5 = MPR5.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		
		MSR1 = MSR1.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		MSR2 = MSR2.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		MSR3 = MSR3.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		MSR4 = MSR4.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		MSR5 = MSR5.getScaledInstance(50,45,Image.SCALE_SMOOTH);
		
		MJ = MJ.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		MJR = MJR.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		MF = MF.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		MFR = MFR.getScaledInstance(30,45,Image.SCALE_SMOOTH);
		
		PokemonArenaBig = new ImageIcon("PokemonArena.png").getImage();
		PokemonArenaBig = PokemonArenaBig.getScaledInstance(900,650,Image.SCALE_SMOOTH);
	    p1x = 170;
        p1y = 280;
        p2y = 280;
        p2x = 670;
        
        choosen=1;
        choosen2=2;
		setSize(900,650);
		
		
	}

    public void update(){
		Graphics g = getGraphics();
	//	System.out.println(p1y,p);
	}
	
    public void setKey(int k, boolean v) {
    	keys[k] = v;
    }
    
	public void collide(){
		
		System.out.println(p1x-p2x);
		if(checkCollide==true){
			if(left==true){
				if((p1x-p2x)<=50 && (p1x-p2x)>=0 && (p1y-p2y)>=-22 && (p1y-p2y)<=22 ){
					System.out.println(p1y-p2y);
					System.out.println("Hi" + ((p1x-p2x)));	
					hp2+=8;
					knockback2=true;
					checkCollide=false;
					p2yy=p2y;
					p2xx=p2x;											
				}
				else{
					checkCollide=false;
				}
			}
			if(left==false){
				if((p2x-p1x)<=50 && (p2x-p1x)>=0 && (p1y-p2y)>=-22 && (p1y-p2y)<=22){
					System.out.println("hiiii" + ((p1y-p2y)));	
					knockback2=true;
					checkCollide=false;
					hp2+=8;
					p2yy=p2y;
					p2xx=p2x;
				}
				else{
					checkCollide=false;
				}
				}
			}
			
			if(checkCollide2==true){
				if(left2==true){
					if((p2x-p1x)<=50 && (p2x-p1x)>=-0 && (p2y-p1y)>=-22 && (p2y-p1y)<=22 ){
	
					//	System.out.println("Hi" + ((p1x-p2x)));	
						hp+=8;
						knockback=true;
						checkCollide=false;	
						p1yy=p1y;
						p1xx=p1x;										
					}
					else{
						checkCollide=false;
					}
				}
				if(left2==false){
					if((p1x-p2x)<=50 && (p1x-p2x)>=0 && (p2y-p1y)>=-22 && (p2y-p1y)<=22){
					//	System.out.println("hiiii" + ((p1y-p2y)));	
						knockback=true;
						checkCollide2=false;
						p1yy=p1y;
						p1xx=p1x;	
						hp+=8;
					}
					else{
						checkCollide2=false;
					}
					}
			}
			
				
		}
	//	if(right==true)
	
	public void refresh(){
		if(p1y<282 && p1y>278){
			onGround=true;
		}
		if(p1y<160 && p1y>154 ){
			if(p1x+15>240 && p1x+15<374){
				onGround=true;	
			}
			else if(p1x+15>546 && p1x+15<680){
				onGround=true;
			}
			else{
				onGround=false;
			}
		}
		if(p1x+15<93 || p1x+15>825){
			onGround=false;
		}
		if(keys[KeyEvent.VK_RIGHT] && knockback==false){
			if(basic==false && special==false){
				if(choosen==5 || choosen==9 || choosen==8 || choosen==10){
					p1x +=3;
				}
				if(choosen==1 || choosen==2 || choosen==3 || choosen==6){
					p1x +=2;
				}
				if(choosen==4  || choosen==7){
					p1x +=1;
				}
					
			}
			
			if(right==false && basic==false && special==false){
				right=true;
				left=false;
				timer=0;
			}
		}	
		if(keys[KeyEvent.VK_O] && keys[KeyEvent.VK_P]==false){
			
			if(basic!=true){
				timer=0;
				basic=true;
				up=false;
				special=false;
			}
			
			
		}
		if(keys[KeyEvent.VK_P]){
			
			if(special!=true){
				timer=0;
				special=true;
				up=false;
				basic=false;
			}
			
			
		}	
		if(keys[KeyEvent.VK_F] && keys[KeyEvent.VK_G]==false){
			
			if(basic2!=true){
				timer2=0;
				basic2=true;
				up2=false;
				special2=false;
			}
			
			
		}	
		if(keys[KeyEvent.VK_G]){
			
			if(special2!=true){
				timer2=0;
				basic2=false;
				up2=false;
				special2=true;
			}
			
			
		}
		if(keys[KeyEvent.VK_LEFT] && keys[KeyEvent.VK_RIGHT]==false && knockback==false){
			if(basic==false && special==false){
				if(choosen==5 || choosen==9 || choosen==8 || choosen==10){
					p1x -=3;
				}
				if(choosen==1 || choosen==2 || choosen==3 || choosen==6){
					p1x -=2;
				}
				if(choosen==4  || choosen==7){
					p1x -=1;
				}
			}
			
			if(left==false  && basic==false && special==false){
				left=true;
				right=false;
				timer=0;
					
			}
			
		}
		//System.out.println(right);
		if(keys[KeyEvent.VK_LEFT]==false){
			left=false;
		}
		if(keys[KeyEvent.VK_RIGHT]==false){
			right=false;
		}
		if(keys[KeyEvent.VK_UP]  ){
			if(onGround==true && up==false){
				up=true;
				p1yy=p1y;
				onGround=false;
				timer=0;
		}
		}
		
		if(onGround==false && up==false){
			if(choosen==5 || choosen==9 || choosen==8 || choosen==10){
					p1y +=1;
				}
			if(choosen==1 || choosen==2 || choosen==3 || choosen==6){
				p1y +=2;
			}
			if(choosen==4  || choosen==7){
				p1y +=3;
			}
		}
		
		if(p2y<282 && p2y>278){
			onGround2=true;
		}
		if(p2y<160 && p2y>154 ){
			if(p2x+15>240 && p2x+15<374){
				onGround2=true;	
			}
			else if(p2x+15>546 && p2x+15<680){
				onGround2=true;
			}
			else{
				onGround2=false;
			}
		}
		if(p2x<93 || p2x>825){
			onGround2=false;
		}
		if(keys[KeyEvent.VK_D]  && knockback2==false ){
			if(basic2==false && special2==false){
				if(choosen2==5 || choosen2==9 || choosen2==8 || choosen2==10){
					p2x +=3;
				}
				if(choosen2==1 || choosen2==2 || choosen2==3 || choosen2==6){
					p2x +=2;
				}
				if(choosen2==4  || choosen2==7){
					p2x +=1;
				}
			}
			
			if(right2==false && special2==false && basic==false){
				right2=true;
				left2=false;
				timer2=0;
			}
		}	
		if(keys[KeyEvent.VK_A] && keys[KeyEvent.VK_D]==false && knockback2==false){
			if(basic2==false && special2==false){
				if(choosen2==5 || choosen2==9 || choosen2==8 || choosen2==10){
					p2x -=3;
				}
				if(choosen2==1 || choosen2==2 || choosen2==3 || choosen2==6){
					p2x -=2;
				}
				if(choosen2==4  || choosen2==7){
					p2x -=1;
				}
			}
			
			if(left2==false && basic2==false && special2==false){
				left2=true;
				right2=false;
				timer2=0;	
			}
			
		}
		if(keys[KeyEvent.VK_A]==false){
			left2=false;
		}
		if(keys[KeyEvent.VK_D]==false){
			right2=false;
		}
		if(keys[KeyEvent.VK_W]  ){
			if(onGround2==true && up2==false){
				up2=true;
				p2yy=p2y;
				onGround2=false;
				timer2=0;
				
		}
		}
		
		if(onGround2==false && up2==false){
			if(choosen2==5 || choosen2==9 || choosen2==8 || choosen2==10){
					p2y +=1;
				}
			if(choosen2==1 || choosen2==2 || choosen2==3 || choosen2==6){
				p2y +=2;
			}
			if(choosen2==4  || choosen2==7){
				p2y +=3;
			}
		}
	//	g.fillRect(93,340,732,130);
	}
	

    public void paintComponent(Graphics g){
    	
		g.setColor(Color.white);
		g.drawImage(PokemonArenaBig,0,0,this);
	//	g.drawImage(Captain,p1x,p2y,this);
		g.drawImage(P1C,p1x+5,p1y-20,this);
		g.drawImage(P2C,p2x+5,p2y-20,this);
		g.drawRect(p1x,p1y,50,45);
		if(p1y>650 || p1x<0 || p1x>950){
			p1y=280;
			p1x=170;
		}
		if(p2y>650 || p2x<0 || p2x>950){
			p2y=280;
			p2x=670;
		}
		if(up==false && onGround==true && timer>500 && knockback==false){
			if((p1y-280)<5 && (p1y-280)>-5){
				p1y=280;
			}
			
		}
		if(up2==false && onGround2==true && timer>500 && knockback==false){
			if((p2y-280)<5 && (p1y-280)>-5){
				p1y=280;
			}
			
		}
		if(knockback==true){
				if(p2x>p1xx){
					p1x-=2;
					p1y-=4;
					if(p1yy-p1y==100){
					knockback=false;		
				}
					onGround=false;
					
				}
				else{
					p1x+=2;
					p1y-=4;
					
					if(p1yy-p1y==100){
					knockback=false;		
				}
					onGround=false;
				}
				
			}
			if(knockback2==true){
				if(p1x>p2xx){
					p2x-=2;
					p2y-=4;
					if(p2yy-p2y==100){
					knockback2=false;		
				}
					onGround2=false;
					
				}
				else{
					p2x+=2;
					p2y-=4;
					
					if(p2yy-p2y==100){
						knockback2=false;		
				}
					onGround2=false;
				}
				
			}
		if(basic==true){
			if(timer==80){
				checkCollide=true;
			}
		}
		if(special==true){
			if(timer==120){
				checkCollide=true;
			}
		}
		if(basic2==true){
			if(timer2==80){
				checkCollide2=true;
			}
		}
		if(special2==true){
			if(timer2==120){
				checkCollide2=true;
			}
		}
		
		if(choosen==1){
			if(right==false && left==false && onGround==true && basic==false && special==false){
				g.drawImage(Mario,p1x,p1y,this);
			}
			if(right==true && onGround==true && basic==false && special==false){
				if(timer>40){
					timer=0;
				}
				if(timer>0 && timer<=10){
					g.drawImage(MWR1,p1x,p1y,this);	
				}
				if(timer>10 && timer<=20){
					g.drawImage(MWR2,p1x,p1y,this);	
				}
				if(timer>20 && timer<=30){
					g.drawImage(MWR3,p1x,p1y,this);	
				}
				if(timer>30 && timer<=40){
					g.drawImage(MWR4,p1x,p1y,this);	
					timer=0;
				}
			}
			if(basic==true && special==false){
				if(left==true){
					if(timer>0 && timer<=16){
						g.drawImage(MP1,p1x,p1y,this);	
					}
					if(timer>16 && timer<=32){
						g.drawImage(MP2,p1x,p1y,this);	
					}
					if(timer>32 && timer<=48){

						g.drawImage(MP3,p1x,p1y,this);	
					}
					if(timer>48 && timer<=64){
						i+=1;
						g.drawImage(MP4,p1x+1,p1y,this);	
					}
					if(timer>64 && timer<=80){
						i-=1;
						g.drawImage(MP5,p1x+i,p1y,this);	
					}
					if(timer>80){
						i=0;
						basic=false;
					}
				}
				if(left==false){
					if(timer>0 && timer<=16){
						g.drawImage(MPR1,p1x,p1y,this);	
					}
					if(timer>16 && timer<=32){
						g.drawImage(MPR2,p1x,p1y,this);	
					}
					if(timer>32 && timer<=48){

						g.drawImage(MPR3,p1x,p1y,this);	
					}
					if(timer>48 && timer<=64){
						i+=1;
						g.drawImage(MPR4,p1x+1,p1y,this);	
					}
					if(timer>64 && timer<=80){
						i-=1;
						g.drawImage(MPR5,p1x+i,p1y,this);	
					}
					if(timer>80){
						i=0;
						basic=false;
					}
				}
			}
			if(basic==false && special==true){
				if(left==true){
					if(timer>0 && timer<=45){
						g.drawImage(MS1,p1x,p1y,this);	
					}
					if(timer>45 && timer<=90){
						g.drawImage(MS2,p1x,p1y,this);	
					}
					if(timer>100 && timer<=110){

						g.drawImage(MS3,p1x,p1y,this);	
					}
					if(timer>100 && timer<=110){
						g.drawImage(MS4,p1x,p1y,this);	
					}
					if(timer>110 && timer<=120){
						g.drawImage(MS5,p1x,p1y,this);	
					}
					if(timer>120){
						special=false;
					}
				}
				if(left==false){
					if(timer>0 && timer<=45){
						g.drawImage(MSR1,p1x,p1y,this);	
					}
					if(timer>45 && timer<=90){
						g.drawImage(MSR2,p1x,p1y,this);	
					}
					if(timer>90 && timer<=100){

						g.drawImage(MSR3,p1x,p1y,this);	
					}
					if(timer>100 && timer<=110){

						g.drawImage(MSR4,p1x,p1y,this);	
					}
					if(timer>110 && timer<=120){

						g.drawImage(MSR5,p1x,p1y,this);	
					}
					if(timer>120){
						i=0;
						special=false;
					}
				}
			}
			if(up==true && basic==false && special==false){
				p1y-=2;
				if(right==true){
					g.drawImage(MJR,p1x,p1y,this);	
				}
				if(right==false){
					g.drawImage(MJ,p1x,p1y,this);	
				}
				if(p1yy-p1y==150 || onGround==true){
					up=false;		
				}
			}
			if(up==false && onGround==false && basic==false && special==false){
				if(right==true){
					g.drawImage(MFR,p1x,p1y,this);	
					}
				if(right==false){
					g.drawImage(MF,p1x,p1y,this);	
					}
			}
			if(left==true && onGround==true && basic==false && special==false){
				if(timer>40){
					timer=0;
				}
				if(timer>0 && timer<=10){
					g.drawImage(MW1,p1x,p1y,this);	
				}
				if(timer>10 && timer<=20){
					g.drawImage(MW2,p1x,p1y,this);	
				}
				if(timer>20 && timer<=30){
					g.drawImage(MW3,p1x,p1y,this);	
				}
				if(timer>30 && timer<=40){
					g.drawImage(MW4,p1x,p1y,this);	
					timer=0;
				}
			}
		}
		if(choosen2==1){
			if(right2==false && left2==false && onGround2==true && basic2==false && special2==false){
				g.drawImage(Mario,p2x,p2y,this);
			}
			if(right2==true && onGround2==true && basic2==false && special2==false){
				if(timer2>40){
					timer2=0;
				}
				if(timer2>0 && timer2<=10){
					g.drawImage(MWR1,p2x,p2y,this);	
				}
				if(timer2>10 && timer2<=20){
					g.drawImage(MWR2,p2x,p2y,this);	
				}
				if(timer2>20 && timer2<=30){
					g.drawImage(MWR3,p2x,p2y,this);	
				}
				if(timer2>30 && timer2<=40){
					g.drawImage(MWR4,p2x,p2y,this);	
					timer2=0;
				}
			}
			if(basic2==true && special2==false){
				if(left2==true){
					if(timer2>0 && timer2<=16){
						g.drawImage(MP1,p2x,p2y,this);	
					}
					if(timer2>16 && timer2<=32){
						g.drawImage(MP2,p2x,p2y,this);	
					}
					if(timer2>32 && timer2<=48){

						g.drawImage(MP3,p2x,p2y,this);	
					}
					if(timer2>48 && timer2<=64){
						i+=1;
						g.drawImage(MP4,p2x+1,p2y,this);	
					}
					if(timer2>64 && timer2<=80){
						i-=1;
						g.drawImage(MP5,p2x+i,p2y,this);	
					}
					if(timer2>80){
						i=0;
						basic2=false;
					}
				}
				if(left2==false){
					if(timer2>0 && timer2<=16){
						g.drawImage(MPR1,p2x,p2y,this);	
					}
					if(timer2>16 && timer2<=32){
						g.drawImage(MPR2,p2x,p2y,this);	
					}
					if(timer2>32 && timer2<=48){

						g.drawImage(MPR3,p2x,p2y,this);	
					}
					if(timer2>48 && timer2<=64){
						i+=1;
						g.drawImage(MPR4,p2x+1,p2y,this);	
					}
					if(timer2>64 && timer2<=80){
						i-=1;
						g.drawImage(MPR5,p2x+i,p2y,this);	
					}
					if(timer2>80){
						timer2=0;
						basic2=false;
					}
				}
			}
			if(basic2==false && special2==true){
				if(left2==true){
					if(timer2>0 && timer2<=45){
						g.drawImage(MS1,p2x,p2y,this);	
					}
					if(timer2>45 && timer2<=90){
						g.drawImage(MS2,p2x,p2y,this);	
					}
					if(timer2>90 && timer2<=100){

						g.drawImage(MS3,p2x,p2y,this);	
					}
					if(timer2>100 && timer2<=110){
	
						g.drawImage(MS4,p2x,p2y,this);	
					}
					if(timer2>110 && timer2<=120){
						g.drawImage(MS5,p2x,p2y,this);	
					}
					if(timer2>120){

						special2=false;
					}
				}
				if(left2==false){
					if(timer2>0 && timer2<=45){
						g.drawImage(MSR1,p2x,p2y,this);	
					}
					if(timer2>45 && timer2<=90){
						g.drawImage(MSR2,p2x,p2y,this);	
					}
					if(timer2>90 && timer2<=100){

						g.drawImage(MSR3,p2x,p2y,this);	
					}
					if(timer2>100 && timer2<=110){

						g.drawImage(MSR4,p2x+1,p2y,this);	
					}
					if(timer2>110 && timer2<=120){
						g.drawImage(MSR5,p2x,p2y,this);	
					}
					if(timer2>120){
						timer2=0;
						special2=false;
					}
				}
			}
			if(up2==true && basic2==false && special2==false){
				p2y-=2;
				if(right2==true){
					g.drawImage(MJR,p2x,p2y,this);	
				}
				if(right2==false){
					g.drawImage(MJ,p2x,p2y,this);	
				}
				if(p2yy-p2y==150 || onGround2==true){
					up2=false;		
				}
			}
			if(up2==false && onGround2==false && basic2==false && special2==false){
				if(right2==true){
					g.drawImage(MFR,p2x,p2y,this);	
					}
				if(right2==false){
					g.drawImage(MF,p2x,p2y,this);	
					}
			}
			if(left2==true && onGround2==true && basic2==false && special2==false){
				if(timer2>40){
					timer2=0;
				}
				if(timer2>0 && timer2<=10){
					g.drawImage(MW1,p2x,p2y,this);	
				}
				if(timer2>10 && timer2<=20){
					g.drawImage(MW2,p2x,p2y,this);	
				}
				if(timer2>20 && timer2<=30){
					g.drawImage(MW3,p2x,p2y,this);	
				}
				if(timer2>30 && timer2<=40){
					g.drawImage(MW4,p2x,p2y,this);	
					timer2=0;
				}
			}
		}
		if(choosen2==2){
			if(right2==false && left2==false && onGround2==true && basic2==false && special2==false){
				g.drawImage(Luigi,p2x,p2y,this);
			}
			if(right2==true && onGround2==true && basic2==false && special2==false){
				if(timer2>80){
					timer2=0;
				}
				if(timer2>0 && timer2<=10){
					g.drawImage(LuW1,p2x,p2y,this);	
				}
				if(timer2>10 && timer2<=20){
					g.drawImage(LuW2,p2x,p2y,this);	
				}
				if(timer2>20 && timer2<=30){
					g.drawImage(LuW3,p2x,p2y,this);
				}
				if(timer2>30 && timer2<=40){
					g.drawImage(LuW4,p2x,p2y,this);	
					
				}
				if(timer2>40 && timer2<=50){
					g.drawImage(LuW5,p2x,p2y,this);	
				}
				if(timer2>50 && timer2<=60){
					g.drawImage(LuW6,p2x,p2y,this);
						
				}
				if(timer2>60 && timer2<=70){
					g.drawImage(LuW5,p2x,p2y,this);	
				}
				if(timer2>70 && timer2<=80){
					g.drawImage(LuW6,p2x,p2y,this);
					timer2=0;	
				}
			}
			if(basic2==true && special2==false){
				if(left2==false){
					if(timer2>0 && timer2<=20){
					g.drawImage(LuP1,p2x,p2y,this);
				
					}
					if(timer2>20 && timer2<=40){
						g.drawImage(LuP2,p2x,p2y,this);	
					}
					if(timer2>40 && timer2<=60){
						g.drawImage(LuP3,p2x,p2y,this);
					}
					if(timer2>60 && timer2<=80){
						g.drawImage(LuP4,p2x,p2y,this);	
						
					}
					if(timer2>80){
						basic2=false;
					}
				}
				if(left2==true){
					if(timer2>0 && timer2<=20){
					g.drawImage(LuPL1,p2x,p2y,this);
				
					}
					if(timer2>20 && timer2<=40){
						g.drawImage(LuPL2,p2x,p2y,this);	
					}
					if(timer2>40 && timer2<=60){
						g.drawImage(LuPL3,p2x,p2y,this);
					}
					if(timer2>60 && timer2<=80){
						g.drawImage(LuPL4,p2x,p2y,this);	
						
					}
					if(timer2>80){
						basic2=false;
					}
				}
				
			}
			if(basic2==false && special2==true){
				if(left2==false){
					if(timer2>0 && timer2<=40){
						g.drawImage(LuS1,p2x,p2y,this);
				
					}
					if(timer2>40 && timer2<=60){
						g.drawImage(LuS2,p2x,p2y,this);	
					}
					if(timer2>60 && timer2<=80){
						g.drawImage(LuS3,p2x,p2y,this);
					}
					if(timer2>80 && timer2<=100){
						g.drawImage(LuS4,p2x,p2y,this);	
						
					}
					if(timer2>100 && timer2<=120){
						g.drawImage(LuS5,p2x,p2y,this);	
						
					}
					if(timer2>120){
						special2=false;
					}
				}
				if(left2==true){
					if(timer2>0 && timer2<=40){
						g.drawImage(LuSL1,p2x,p2y,this);
				
					}
					if(timer2>40 && timer2<=60){
						g.drawImage(LuSL2,p2x,p2y,this);	
					}
					if(timer2>60 && timer2<=80){
						g.drawImage(LuSL3,p2x,p2y,this);
					}
					if(timer2>80 && timer2<=100){
						g.drawImage(LuSL4,p2x,p2y,this);	
						
					}
					if(timer2>100 && timer2<=120){
						g.drawImage(LuSL5,p2x,p2y,this);	
						
					}
					if(timer2>120){
						special2=false;
					}
				}
				
			}
			if(up2==true && basic2==false && special2==false){
				p2y-=2;
				if(right2==true){
					g.drawImage(LuJ,p2x,p2y,this);	
				}
				if(right2==false){
					g.drawImage(LuJL,p2x,p2y,this);	
				}
				if(p2yy-p2y==150 || onGround2==true){
					up2=false;		
				}
			}
			if(up2==false && onGround2==false && basic2==false && special2==false){
				if(right2==true){
					if(timer2>40){
						timer2=0;
					}
					if(timer2>0 && timer2<=10){
						g.drawImage(LuF1,p2x,p2y,this);	
					}
					if(timer2>10 && timer2<=20){
						g.drawImage(LuF2,p2x,p2y,this);	
					}
					if(timer2>20 && timer2<=30){
						g.drawImage(LuF3,p2x,p2y,this);
					}
					if(timer2>30 && timer2<=40){
						g.drawImage(LuF4,p2x,p2y,this);	
						timer=0;
					}
						
				}
			if(right2==false && basic2==false && special2==false){
				if(timer2>40){
					timer2=0;
				}
				if(timer2>0 && timer2<=10){
					g.drawImage(LuFL1,p2x,p2y,this);	
				}
				if(timer2>10 && timer2<=20){
					g.drawImage(LuFL2,p2x,p2y,this);	
				}
				if(timer2>20 && timer2<=30){
					g.drawImage(LuFL3,p2x,p2y,this);
				}
				if(timer2>30 && timer2<=40){
					g.drawImage(LuFL4,p2x,p2y,this);	
					timer=0;
				}	
				}
		}
			if(left2==true && onGround2==true && basic2==false && special2==false){
				if(timer2>80){
					timer2=0;
				}
				if(timer2>0 && timer2<=10){
					g.drawImage(LuWL1,p2x,p2y,this);	
				}
				if(timer2>10 && timer2<=20){
					g.drawImage(LuWL2,p2x,p2y,this);	
				}
				if(timer2>20 && timer2<=30){
					g.drawImage(LuWL3,p2x,p2y,this);
				}
				if(timer2>30 && timer2<=40){
					g.drawImage(LuWL4,p2x,p2y,this);	
					
				}
				if(timer2>40 && timer2<=50){
					g.drawImage(LuWL5,p2x,p2y,this);	
				}
				if(timer2>50 && timer2<=60){
					g.drawImage(LuWL6,p2x,p2y,this);	
				}
				if(timer2>60 && timer2<=70){
					g.drawImage(LuWL7,p2x,p2y,this);	
				}
				if(timer2>70 && timer2<=80){
					g.drawImage(LuWL8,p2x,p2y,this);
					timer2=0;	
				}
			}
		}
		if(choosen==3){
			if(right==false && left==false && onGround==true && basic==false && special==false){
				g.drawImage(Peach,p1x,p1y,this);
			}
			if(right==true && onGround==true && basic==false && special==false){
				if(timer>60){
					timer=0;
				}
				if(timer>0 && timer<=10){
					g.drawImage(PW1,p1x,p1y,this);	
				}
				if(timer>10 && timer<=20){
					g.drawImage(PW2,p1x,p1y,this);	
				}
				if(timer>20 && timer<=30){
					g.drawImage(PW3,p1x,p1y,this);	
				}
				if(timer>30 && timer<=40){
					g.drawImage(PW4,p1x,p1y,this);
				}
				if(timer>40 && timer<=50){
					g.drawImage(PW5,p1x,p1y,this);	
				}
				if(timer>50 && timer<=60){
					g.drawImage(PW6,p1x,p1y,this);
					timer=0;	
				}	
			}
			if(basic==true && special==false){
				if(left==true){
					if(timer>0 && timer<=20){
						g.drawImage(PPL1,p1x,p1y,this);	
					}
					if(timer>20 && timer<=40){
						g.drawImage(PPL2,p1x,p1y,this);	
					}
					if(timer>40 && timer<=60){
						g.drawImage(PPL3,p1x,p1y,this);	
					}
					if(timer>60 && timer<=80){
						g.drawImage(PPL4,p1x,p1y,this);	
					}
					if(timer>80){
						basic=false;
					}
				}
				if(left==false){
					if(timer>0 && timer<=20){
						g.drawImage(PP1,p1x,p1y,this);	
					}
					if(timer>20 && timer<=40){
						g.drawImage(PP2,p1x,p1y,this);	
					}
					if(timer>40 && timer<=60){
						g.drawImage(PP3,p1x,p1y,this);	
					}
					if(timer>60 && timer<=80){
						g.drawImage(PP4,p1x,p1y,this);	
					}
					if(timer>80){
						basic=false;
					}
				}
			}
			if(basic==false && special==true){
				if(left==true){
					if(timer>0 && timer<=30){
						g.drawImage(PSL1,p1x,p1y,this);	
					}
					if(timer>30 && timer<=60){
						g.drawImage(PSL2,p1x,p1y,this);	
					}
					if(timer>60 && timer<=70){
						g.drawImage(PSL3,p1x,p1y,this);	
					}
					if(timer>70 && timer<=80){
						g.drawImage(PSL4,p1x,p1y,this);	
					}
					if(timer>80 && timer<=90){
						g.drawImage(PSL5,p1x,p1y,this);	
					}
					if(timer>90 && timer<=100){
						g.drawImage(PSL6,p1x,p1y,this);	
					}
					if(timer>100 && timer<=110){
						g.drawImage(PSL7,p1x,p1y,this);	
					}
					if(timer>110 && timer<=120){
						g.drawImage(PSL8,p1x,p1y,this);	
					}
					if(timer>120){
						special=false;
					}
				}
				if(left==false){
					if(timer>0 && timer<=30){
						g.drawImage(PS1,p1x,p1y,this);	
					}
					if(timer>30 && timer<=60){
						g.drawImage(PS2,p1x,p1y,this);	
					}
					if(timer>60 && timer<=70){
						g.drawImage(PS3,p1x,p1y,this);	
					}
					if(timer>70 && timer<=80){
						g.drawImage(PS4,p1x,p1y,this);	
					}
					if(timer>80 && timer<=90){
						g.drawImage(PS5,p1x,p1y,this);	
					}
					if(timer>90 && timer<=100){
						g.drawImage(PS6,p1x,p1y,this);	
					}
					if(timer>100 && timer<=110){
						g.drawImage(PS7,p1x,p1y,this);	
					}
					if(timer>110 && timer<=120){
						g.drawImage(PS8,p1x,p1y,this);	
					}
					if(timer>120){
						special=false;
					}
				}
			}
			if(up==true && basic==false && special==false){
				p1y-=2;
				
				if(left==false){
					g.drawImage(PJ,p1x,p1y,this);
				}
				if(left==true){
					g.drawImage(PJL,p1x,p1y,this);
				}	
				
				if(p1yy-p1y==150 || onGround==true){
					up=false;
				}		
		}
		
			if(up==false && onGround==false && basic==false && special==false){
				if(left==false){
					g.drawImage(PF,p1x,p1y,this);
				}
				if(left==true){
					g.drawImage(PFL,p1x,p1y,this);
				}
				
			}
			if(left==true && onGround==true && basic==false && special==false){
				if(timer>60){
					timer=0;
				}
				if(timer>0 && timer<=10){
					g.drawImage(PWL1,p1x,p1y,this);	
				}
				if(timer>10 && timer<=20){
					g.drawImage(PWL2,p1x,p1y,this);	
				}
				if(timer>20 && timer<=30){
					g.drawImage(PWL3,p1x,p1y,this);	
				}
				if(timer>30 && timer<=40){
					g.drawImage(PWL4,p1x,p1y,this);
					timer=0;	
				}
				if(timer>40 && timer<=50){
					g.drawImage(PWL5,p1x,p1y,this);	
				}
				if(timer>50 && timer<=60){
					g.drawImage(PWL6,p1x,p1y,this);	
					timer=0;
				}
			}
		}
		if(choosen==4){
			if(right==false && left==false && onGround==true && basic==false && special==false){
				g.drawImage(Dk,p1x,p1y,this);
			}
			if(right==true && onGround==true && basic==false && special==false){
				if(timer>40){
					timer=0;
				}
				if(timer>0 && timer<=10){
					g.drawImage(DW1,p1x,p1y,this);	
				}
				if(timer>10 && timer<=20){
					g.drawImage(DW2,p1x,p1y,this);	
				}
				if(timer>20 && timer<=30){
					g.drawImage(DW3,p1x,p1y,this);	
				}
				if(timer>30 && timer<=40){
					g.drawImage(DW4,p1x,p1y,this);
					timer=0;	
				}	
			}
			if(basic==true && special==false){
				if(left==true){
					if(timer>0 && timer<=40){
						g.drawImage(DP1,p1x,p1y,this);	
					}
					if(timer>40 && timer<=80){
						g.drawImage(DPL,p1x,p1y,this);	
					}
					if(timer>80){
						basic=false;
					}
				}
				if(left==false){
					if(timer>0 && timer<=40){
						g.drawImage(DP1,p1x,p1y,this);	
					}
					if(timer>40 && timer<=80){
						g.drawImage(DP2,p1x,p1y,this);	
					}
					if(timer>80){
						basic=false;
					}
				}
			}
			if(basic==false && special==true){
				if(timer>0 && timer<=24){
					g.drawImage(DS1,p1x,p1y,this);	
				}
				if(timer>24 && timer<=48){
					g.drawImage(DS2,p1x,p1y,this);	
				}
				if(timer>48 && timer<=72){
					g.drawImage(DS1,p1x,p1y,this);	
				}
				if(timer>72 && timer<=96){
					g.drawImage(DS2,p1x,p1y,this);	
				}
				if(timer>96 && timer<=120){
					g.drawImage(DS3,p1x,p1y,this);	
				}
				if(timer==120){
					special=false;
				}
				
			}
			if(up==true && basic==false && special==false){
				p1y-=1;
				if(timer>0 && timer<=10){
					g.drawImage(DJ1,p1x,p1y,this);	
				}	
				if(timer>10 && timer<=20){
					g.drawImage(DJ2,p1x,p1y,this);	
				}
				if(timer>20 && timer<=30){
					g.drawImage(DJ3,p1x,p1y,this);	
				}
				if(timer>30 && timer<=40){
					g.drawImage(DJ4,p1x,p1y,this);
						
				}
				if(timer>40 && timer<=50){
					g.drawImage(DJ5,p1x,p1y,this);
						
				}	
				if(timer>50 && timer<=60){
					g.drawImage(DJ6,p1x,p1y,this);
					timer=0;
						
				}
				if(p1yy-p1y==150 || onGround==true){
					up=false;
				}		
		}
			if(up==false && onGround==false && basic==false && special==false){
				if(timer>60){
					timer=0;
				}
				if(timer>0 && timer<=10){
					g.drawImage(DJ1,p1x,p1y,this);	
				}	
				if(timer>10 && timer<=20){
					g.drawImage(DJ2,p1x,p1y,this);	
				}
				if(timer>20 && timer<=30){
					g.drawImage(DJ3,p1x,p1y,this);	
				}
				if(timer>30 && timer<=40){
					g.drawImage(DJ4,p1x,p1y,this);
						
				}
				if(timer>40 && timer<=50){
					g.drawImage(DJ5,p1x,p1y,this);
						
				}	
				if(timer>50 && timer<=60){
					g.drawImage(DJ6,p1x,p1y,this);
					timer=0;
						
				}
			}
			if(left==true && onGround==true && basic==false && special==false){
				if(timer>40){
					timer=0;
				}
				if(timer>0 && timer<=10){
					g.drawImage(DWL1,p1x,p1y,this);	
				}
				if(timer>10 && timer<=20){
					g.drawImage(DWL2,p1x,p1y,this);	
				}
				if(timer>20 && timer<=30){
					g.drawImage(DWL3,p1x,p1y,this);	
				}
				if(timer>30 && timer<=40){
					g.drawImage(DWL4,p1x,p1y,this);
					timer=0;	
				}
			
			
			
			}
		
		}
		if(choosen2==3){
			if(right2==false && left2==false && onGround2==true && basic2==false && special2==false){
				g.drawImage(Peach,p2x,p2y,this);
			}
			if(right2==true && onGround2==true && basic2==false && special2==false){
				if(timer2>60){
					timer2=0;
				}
				if(timer2>0 && timer2<=10){
					g.drawImage(PW1,p2x,p2y,this);	
				}
				if(timer2>10 && timer2<=20){
					g.drawImage(PW2,p2x,p2y,this);	
				}
				if(timer2>20 && timer2<=30){
					g.drawImage(PW3,p2x,p2y,this);	
				}
				if(timer2>30 && timer2<=40){
					g.drawImage(PW4,p2x,p2y,this);
				}
				if(timer2>40 && timer2<=50){
					g.drawImage(PW5,p2x,p2y,this);	
				}
				if(timer2>50 && timer2<=60){
					g.drawImage(PW6,p2x,p2y,this);
					timer2=0;	
				}	
			}
			if(basic2==true && special2==false){
				if(left2==true){
					if(timer2>0 && timer2<=20){
						g.drawImage(PPL1,p2x,p2y,this);	
					}
					if(timer2>20 && timer2<=40){
						g.drawImage(PPL2,p2x,p2y,this);	
					}
					if(timer2>40 && timer2<=60){
						g.drawImage(PPL3,p2x,p2y,this);	
					}
					if(timer2>60 && timer2<=80){
						g.drawImage(PPL4,p2x,p2y,this);	
					}
					if(timer2>80){
						basic2=false;
					}
				}
				if(left2==false){
					if(timer2>0 && timer2<=20){
						g.drawImage(PP1,p2x,p2y,this);	
					}
					if(timer2>20 && timer2<=40){
						g.drawImage(PP2,p2x,p2y,this);	
					}
					if(timer2>40 && timer2<=60){
						g.drawImage(PP3,p2x,p2y,this);	
					}
					if(timer2>60 && timer2<=80){
						g.drawImage(PP4,p2x,p2y,this);	
					}
					if(timer2>80){
						basic2=false;
					}
				}
			}
			if(basic2==false && special2==true){
				if(left2==true){
					if(timer2>0 && timer2<=30){
						g.drawImage(SSL1,p2x,p2y,this);	
					}
					if(timer2>30 && timer2<=60){
						g.drawImage(SSL2,p2x,p2y,this);	
					}
					if(timer2>60 && timer2<=70){
						g.drawImage(SSL3,p2x,p2y,this);	
					}
					if(timer2>70 && timer2<=80){
						g.drawImage(SSL4,p2x,p2y,this);	
					}
					if(timer2>80 && timer2<=90){
						g.drawImage(SSL5,p2x,p2y,this);	
					}
					if(timer2>90 && timer2<=100){
						g.drawImage(SSL6,p2x,p2y,this);	
					}
					if(timer2>100 && timer2<=110){
						g.drawImage(SSL7,p2x,p2y,this);	
					}
					if(timer2>110 && timer2<=120){
						g.drawImage(SSL8,p2x,p2y,this);	
					}
					if(timer2>120){
						special2=false;
					}
				}
				if(left2==false){
					if(timer2>0 && timer2<=30){
						g.drawImage(SS1,p2x,p2y,this);	
					}
					if(timer2>30 && timer2<=60){
						g.drawImage(SS2,p2x,p2y,this);	
					}
					if(timer2>60 && timer2<=70){
						g.drawImage(SS3,p2x,p2y,this);	
					}
					if(timer2>70 && timer2<=80){
						g.drawImage(SS4,p2x,p2y,this);	
					}
					if(timer2>80 && timer2<=90){
						g.drawImage(SS5,p2x,p2y,this);	
					}
					if(timer2>90 && timer2<=100){
						g.drawImage(SS6,p2x,p2y,this);	
					}
					if(timer2>100 && timer2<=110){
						g.drawImage(SS7,p2x,p2y,this);	
					}
					if(timer2>110 && timer2<=120){
						g.drawImage(SS8,p2x,p2y,this);	
					}
					if(timer2>120){
						special2=false;
					}
				}
			}
			if(up2==true && basic2==false && special2==false){
				p2y-=2;
				
				if(left2==false){
					g.drawImage(PJ,p2x,p2y,this);
				}
				if(left2==true){
					g.drawImage(PJL,p2x,p2y,this);
				}	
				
				if(p2yy-p2y==150 || onGround2==true){
					up2=false;
				}		
		}
		
			if(up2==false && onGround2==false && basic2==false && special2==false){
				if(left2==false){
					g.drawImage(PF,p2x,p2y,this);
				}
				if(left2==true){
					g.drawImage(PFL,p2x,p2y,this);
				}
				
			}
			if(left2==true && onGround2==true && basic2==false && special2==false){
				if(timer2>60){
					timer2=0;
				}
				if(timer2>0 && timer2<=10){
					g.drawImage(PWL1,p2x,p2y,this);	
				}
				if(timer2>10 && timer2<=20){
					g.drawImage(PWL2,p2x,p2y,this);	
				}
				if(timer2>20 && timer2<=30){
					g.drawImage(PWL3,p2x,p2y,this);	
				}
				if(timer2>30 && timer2<=40){
					g.drawImage(PWL4,p2x,p2y,this);
					timer2=0;	
				}
				if(timer2>40 && timer2<=50){
					g.drawImage(PWL5,p2x,p2y,this);	
				}
				if(timer2>50 && timer2<=60){
					g.drawImage(PWL6,p2x,p2y,this);	
					timer2=0;
				}
			}
		}
		if(choosen2==4){
			if(right2==false && left2==false && onGround2==true && basic2==false && special2==false){
				g.drawImage(Dk,p2x,p2y,this);
			}
			if(right2==true && onGround2==true && basic2==false && special2==false){
				if(timer2>40){
					timer2=0;
				}
				if(timer2>0 && timer2<=10){
					g.drawImage(DW1,p2x,p2y,this);	
				}
				if(timer2>10 && timer2<=20){
					g.drawImage(DW2,p2x,p2y,this);	
				}
				if(timer2>20 && timer2<=30){
					g.drawImage(DW3,p2x,p2y,this);	
				}
				if(timer2>30 && timer2<=40){
					g.drawImage(DW4,p2x,p2y,this);
					timer2=0;	
				}
				
				
			}
			if(basic2==true && special2==false){
				if(left2==true){
					if(timer2>0 && timer2<=40){
						g.drawImage(DP1,p2x,p2y,this);	
					}
					if(timer2>40 && timer2<=80){
						g.drawImage(DPL,p2x,p2y,this);	
					}
					if(timer2>80){
						basic2=false;
					}
				}
				if(left2==false){
					if(timer2>0 && timer2<=40){
						g.drawImage(DP1,p2x,p2y,this);	
					}
					if(timer2>40 && timer2<=80){
						g.drawImage(DP2,p2x,p2y,this);	
					}
					if(timer2>80){
						basic2=false;
					}
				}
			}
			if(basic2==false && special2==true){
				if(timer2>0 && timer2<=24){
					g.drawImage(DS1,p2x,p2y,this);	
				}
				if(timer2>24 && timer2<=48){
					g.drawImage(DS2,p2x,p2y,this);	
				}
				if(timer2>48 && timer2<=72){
					g.drawImage(DS1,p2x,p2y,this);	
				}
				if(timer2>72 && timer2<=96){
					g.drawImage(DS2,p2x,p2y,this);	
				}
				if(timer2>96 && timer2<=120){
					g.drawImage(DS3,p2x,p2y,this);	
				}
				if(timer2==120){
					special2=false;
				}
				
			}
			if(up2==true && special2==false){
				p2y-=1;
				if(timer2>0 && timer2<=10){
					g.drawImage(DJ1,p2x,p2y,this);	
				}	
				if(timer2>10 && timer2<=20){
					g.drawImage(DJ2,p2x,p2y,this);	
				}
				if(timer2>20 && timer2<=30){
					g.drawImage(DJ3,p2x,p2y,this);	
				}
				if(timer2>30 && timer2<=40){
					g.drawImage(DJ4,p2x,p2y,this);
						
				}
				if(timer2>40 && timer2<=50){
					g.drawImage(DJ5,p2x,p2y,this);
						
				}	
				if(timer2>50 && timer2<=60){
					g.drawImage(DJ6,p2x,p2y,this);
					timer2=0;
						
				}
				if(p2yy-p2y==150 || onGround2==true){
					up2=false;
				
				}
				
		}
			if(up2==false && onGround2==false && basic2==false && special2==false){
				if(timer2>60){
					timer2=0;
				}
				if(timer2>0 && timer2<=10){
					g.drawImage(DJ1,p2x,p2y,this);	
				}	
				if(timer2>10 && timer2<=20){
					g.drawImage(DJ2,p2x,p2y,this);	
				}
				if(timer2>20 && timer2<=30){
					g.drawImage(DJ3,p2x,p2y,this);	
				}
				if(timer2>30 && timer2<=40){
					g.drawImage(DJ4,p2x,p2y,this);
						
				}
				if(timer2>40 && timer2<=50){
					g.drawImage(DJ5,p2x,p2y,this);
						
				}	
				if(timer2>50 && timer2<=60){
					g.drawImage(DJ6,p2x,p2y,this);
					timer2=0;
						
				}
			}
			if(left2==true && onGround2==true && basic2==false && special2==false){
				if(timer2>40){
					timer2=0;
				}
				if(timer2>0 && timer2<=10){
					g.drawImage(DWL1,p2x,p2y,this);	
				}
				if(timer2>10 && timer2<=20){
					g.drawImage(DWL2,p2x,p2y,this);	
				}
				if(timer2>20 && timer2<=30){
					g.drawImage(DWL3,p2x,p2y,this);	
				}
				if(timer2>30 && timer2<=40){
					g.drawImage(DWL4,p2x,p2y,this);
					timer2=0;	
				}	
			}
		}
		if(choosen==7){
			if(right==false && left==false && onGround==true && basic==false && special==false){
				g.drawImage(Captain,p1x-15,p1y-15,this);
			}
			if(right==true && onGround==true && basic==false && special==false){
				if(timer>60){
					timer=0;
				}
				if(timer>0 && timer<=10){
					g.drawImage(CW1,p1x-15,p1y-15,this);	
				}
				if(timer>10 && timer<=20){
					g.drawImage(CW2,p1x-15,p1y-15,this);	
				}
				if(timer>20 && timer<=30){
					g.drawImage(CW3,p1x-15,p1y-15,this);
				}
				if(timer>30 && timer<=40){
					g.drawImage(CW4,p1x-15,p1y-15,this);	
				}
				if(timer>40 && timer<=50){
					g.drawImage(CW5,p1x-15,p1y-15,this);	
				}
				if(timer>50 && timer<=60){
					g.drawImage(CW6,p1x-15,p1y-15,this);
					timer=0;	
				}
			}
			if(basic==true && special==false){
				if(left==false){
					if(timer>0 && timer<=13){
						g.drawImage(CP1,p1x-15,p1y-15,this);	
					}
					if(timer>13 && timer<=27){
						g.drawImage(CP2,p1x-15,p1y-15,this);	
					}
					if(timer>27 && timer<=40){
						g.drawImage(CP3,p1x-15,p1y-15,this);	
					}
					if(timer>40 && timer<=53){
						g.drawImage(CP4,p1x-15,p1y-15,this);	
					}
					if(timer>53 && timer<=67){
						g.drawImage(CP5,p1x-15,p1y-15,this);	
					}
					if(timer>67 && timer<=80){
						g.drawImage(CP6,p1x-15,p1y-15,this);	
					}
					if(timer>80){
						basic=false;
					}
				}
				
				if(left==true){
					if(timer>0 && timer<=13){
						g.drawImage(CPL1,p1x-15,p1y-15,this);	
					}
					if(timer>13 && timer<=27){
						g.drawImage(CPL2,p1x-15,p1y-15,this);	
					}
					if(timer>27 && timer<=40){
						g.drawImage(CPL3,p1x-15,p1y-15,this);	
					}
					if(timer>40 && timer<=53){
						g.drawImage(CPL4,p1x-15,p1y-15,this);	
					}
					if(timer>53 && timer<=67){
						g.drawImage(CPL5,p1x-15,p1y-15,this);	
					}
					if(timer>67 && timer<=80){
						g.drawImage(CPL6,p1x-15,p1y-15,this);	
					}
					if(timer>80){
						basic=false;
					}
				}					
				}
			if(basic==false && special==true){
				if(left==false){
					if(timer>0 && timer<=24){
						g.drawImage(CS1,p1x-15,p1y-15,this);	
					}
					if(timer>24 && timer<=48){
						g.drawImage(CS2,p1x-15,p1y-15,this);	
					}
					if(timer>48 && timer<=72){
						g.drawImage(CS3,p1x-15,p1y-15,this);	
					}
					if(timer>72 && timer<=96){
						g.drawImage(CS4,p1x-15,p1y-15,this);	
					}
					if(timer>96 && timer<=120){
						g.drawImage(CS5,p1x-15,p1y-15,this);	
					}
					if(timer>120){
						special=false;
					}
				}
				
				if(left==true){
					if(timer>0 && timer<=24){
						g.drawImage(CSL1,p1x-15,p1y-15,this);	
					}
					if(timer>24 && timer<=48){
						g.drawImage(CSL2,p1x-15,p1y-15,this);	
					}
					if(timer>48 && timer<=72){
						g.drawImage(CSL3,p1x-15,p1y-15,this);	
					}
					if(timer>72 && timer<=96){
						g.drawImage(CSL4,p1x-15,p1y-15,this);	
					}
					if(timer>96 && timer<=120){
						g.drawImage(CSL5,p1x-15,p1y-15,this);	
					}
					if(timer>120){
						special=false;
					}
				}					
				}
			if(up==true && basic==false && special==false){
				p1y-=1;
				if(right==true){
					g.drawImage(CJ,p1x-15,p1y-15,this);	
				}
				if(right==false){
					g.drawImage(CJL,p1x-15,p1y-15,this);	
				}
				if(p1yy-p1y==150 || onGround==true){
					up=false;		
				}
			}
			if(up==false && onGround==false && basic==false && special==false){
				if(right==true){
					g.drawImage(CF,p1x-15,p1y-15,this);	
					}
				if(right==false){
					g.drawImage(CFL,p1x-15,p1y-15,this);	
					}
			}
			if(left==true && onGround==true && basic==false && special==false){
				if(timer>60){
					timer=0;
				}
				if(timer>0 && timer<=10){
					g.drawImage(CWL1,p1x-15,p1y-15,this);	
				}
				if(timer>10 && timer<=20){
					g.drawImage(CWL2,p1x-15,p1y-15,this);	
				}
				if(timer>20 && timer<=30){
					g.drawImage(CWL3,p1x-15,p1y-15,this);
				}
				if(timer>30 && timer<=40){
					g.drawImage(CWL4,p1x-15,p1y-15,this);	
					
				}
				if(timer>40 && timer<=50){
					g.drawImage(CWL5,p1x-15,p1y-15,this);	
				}
				if(timer>50 && timer<=60){
					g.drawImage(CWL6,p1x-15,p1y-15,this);
					timer=0;	
				}
			}
		}
		if(choosen2==7){
			if(right2==false && left2==false && onGround2==true && basic2==false && special2==false){
				g.drawImage(Captain,p2x-15,p2y-15,this);
			}
			if(right2==true && onGround2==true && basic2==false && special2==false){
				if(timer2>60){
					timer2=0;
				}
				if(timer2>0 && timer2<=10){
					g.drawImage(CW1,p2x-15,p2y-15,this);	
				}
				if(timer2>10 && timer2<=20){
					g.drawImage(CW2,p2x-15,p2y-15,this);	
				}
				if(timer2>20 && timer2<=30){
					g.drawImage(CW3,p2x-15,p2y-15,this);
				}
				if(timer2>30 && timer2<=40){
					g.drawImage(CW4,p2x-15,p2y-15,this);	
					
				}
				if(timer2>40 && timer2<=50){
					g.drawImage(CW5,p2x-15,p2y-15,this);	
				}
				if(timer2>50 && timer2<=60){
					g.drawImage(CW6,p2x-15,p2y-15,this);
					timer2=0;	
				}
			}
			if(basic2==true && special2==false){
				if(left2==false){
					if(timer2>0 && timer2<=13){
						g.drawImage(CP1,p2x-15,p2y-15,this);	
					}
					if(timer2>13 && timer2<=27){
						g.drawImage(CP2,p2x-15,p2y-15,this);	
					}
					if(timer2>27 && timer2<=40){
						g.drawImage(CP3,p2x-15,p2y-15,this);	
					}
					if(timer2>40 && timer2<=53){
						g.drawImage(CP4,p2x-15,p2y-15,this);	
					}
					if(timer2>53 && timer2<=67){
						g.drawImage(CP5,p2x-15,p2y-15,this);	
					}
					if(timer2>67 && timer2<=80){
						g.drawImage(CP6,p2x-15,p2y-15,this);	
					}
					if(timer2>80){
						basic2=false;
					}
				}
				
				if(left2==true && basic2==false){
					if(timer2>0 && timer2<=13){
						g.drawImage(CPL1,p2x-15,p2y-15,this);	
					}
					if(timer2>13 && timer2<=27){
						g.drawImage(CPL2,p2x-15,p2y-15,this);	
					}
					if(timer2>27 && timer2<=40){
						g.drawImage(CPL3,p2x-15,p2y-15,this);	
					}
					if(timer2>40 && timer2<=53){
						g.drawImage(CPL4,p2x-15,p2y-15,this);	
					}
					if(timer2>53 && timer2<=67){
						g.drawImage(CPL5,p2x-15,p2y-15,this);	
					}
					if(timer2>67 && timer2<=80){
						g.drawImage(CPL6,p2x-15,p2y-15,this);	
					}
					if(timer2>80){
						basic2=false;
					}
				}					
				}
				if(basic2==false && special2==true){
					if(left2==false){
						if(timer2>0 && timer2<=24){
							g.drawImage(CS1,p2x-15,p2y-15,this);	
						}
						if(timer2>24 && timer2<=48){
							g.drawImage(CS2,p2x-15,p2y-15,this);	
						}
						if(timer2>48 && timer2<=72){
							g.drawImage(CS3,p2x-15,p2y-15,this);	
						}
						if(timer2>72 && timer2<=96){
							g.drawImage(CS4,p2x-15,p2y-15,this);	
						}
						if(timer2>96 && timer2<=120){
							g.drawImage(CS5,p2x-15,p2y-15,this);	
						}
						if(timer2>120){
							special2=false;
						}
					}
					
					if(left2==true){
						if(timer2>0 && timer2<=24){
							g.drawImage(CSL1,p2x-15,p2y-15,this);	
						}
						if(timer2>24 && timer2<=48){
							g.drawImage(CSL2,p2x-15,p2y-15,this);	
						}
						if(timer2>48 && timer2<=72){
							g.drawImage(CSL3,p2x-15,p2y-15,this);	
						}
						if(timer2>72 && timer2<=96){
							g.drawImage(CSL4,p2x-15,p2y-15,this);	
						}
						if(timer2>96 && timer2<=120){
							g.drawImage(CSL5,p2x-15,p2y-15,this);	
						}
						if(timer2>120){
							special2=false;
						}
					}					
				}
			if(up2==true && basic2==false && special2==false){
				p2y-=1;
				if(right2==true){
					g.drawImage(CJ,p2x-15,p2y-15,this);	
				}
				if(right2==false){
					g.drawImage(CJL,p2x-15,p2y-15,this);	
				}
				if(p2yy-p2y==150 || onGround2==true){
					up2=false;		
				}
			}
			if(up2==false && onGround2==false && basic2==false && special2==false){
				if(right2==true){
					g.drawImage(CF,p2x-15,p2y-15,this);	
					}
				if(right2==false){
					g.drawImage(CFL,p2x-15,p2y-15,this);	
					}
			}
			if(left2==true && onGround2==true && basic2==false && special2==false){
				if(timer2>60){
					timer2=0;
				}
				if(timer2>0 && timer2<=10){
					g.drawImage(CWL1,p2x-15,p2y-15,this);	
				}
				if(timer2>10 && timer2<=20){
					g.drawImage(CWL2,p2x-15,p2y-15,this);	
				}
				if(timer2>20 && timer2<=30){
					g.drawImage(CWL3,p2x-15,p2y-15,this);
				}
				if(timer2>30 && timer2<=40){
					g.drawImage(CWL4,p2x-15,p2y-15,this);	
					
				}
				if(timer2>40 && timer2<=50){
					g.drawImage(CWL5,p2x-15,p2y-15,this);	
				}
				if(timer2>50 && timer2<=60){
					g.drawImage(CWL6,p2x-15,p2y-15,this);
					timer2=0;	
				}
			}
		}
		if(choosen==8){
			if(right==false && left==false && onGround==true && basic==false && special==false ){
				g.drawImage(Fox,p1x,p1y,this);
			}
			if(right==true && onGround==true && basic==false && special==false){
				if(timer>60){
					timer=0;
				}
				if(timer>0 && timer<=10){
					g.drawImage(FW1,p1x,p1y,this);	
				}
				if(timer>10 && timer<=20){
					g.drawImage(FW2,p1x,p1y,this);	
				}
				if(timer>20 && timer<=30){
					g.drawImage(FW3,p1x,p1y,this);	
				}
				if(timer>30 && timer<=40){
					g.drawImage(FW4,p1x,p1y,this);	
				}
				if(timer>40 && timer<=50){
					g.drawImage(FW5,p1x,p1y,this);	
				}
				if(timer>50 && timer<=60){
					g.drawImage(FW6,p1x,p1y,this);
					timer=0;	
				}
			}
			if(basic==true && special==false){
				if(left==true){
					if(timer>0 && timer<=20){
						g.drawImage(FPL1,p1x,p1y,this);	
					}
					if(timer>20 && timer<=40){
						g.drawImage(FPL2,p1x,p1y,this);	
					}
					if(timer>40 && timer<=60){
						g.drawImage(FPL3,p1x,p1y,this);	
					}
					if(timer>60 && timer<=80){
						g.drawImage(FPL4,p1x,p1y,this);	
					}
					if(timer>80){
						basic=false;
					}
				}
				if(left==false){
					if(timer>0 && timer<=20){
						g.drawImage(FP1,p1x,p1y,this);	
					}
					if(timer>20 && timer<=40){
						g.drawImage(FP2,p1x,p1y,this);	
					}
					if(timer>40 && timer<=60){
						g.drawImage(FP3,p1x,p1y,this);	
					}
					if(timer>60 && timer<=80){
						g.drawImage(FP4,p1x,p1y,this);	
					}
					if(timer>80){
						basic=false;
					}
				}
			}
			if(basic==false && special==true){
				if(left==true){
					if(timer>0 && timer<=30){
						g.drawImage(FSL1,p1x,p1y,this);	
					}
					if(timer>30 && timer<=60){
						g.drawImage(FSL2,p1x,p1y,this);	
					}
					if(timer>60 && timer<=90){
						g.drawImage(FSL3,p1x,p1y,this);	
					}
					if(timer>90 && timer<=120){
						g.drawImage(FSL4,p1x,p1y,this);	
					}
					if(timer>120){
						special=false;
					}
				}
				if(left==false){
					if(timer>0 && timer<=30){
						g.drawImage(FS1,p1x,p1y,this);	
					}
					if(timer>30 && timer<=60){
						g.drawImage(FS2,p1x,p1y,this);	
					}
					if(timer>60 && timer<=90){
						g.drawImage(FS3,p1x,p1y,this);	
					}
					if(timer>90 && timer<=120){
						g.drawImage(FS4,p1x,p1y,this);	
					}
					if(timer>120){
						special=false;
					}
				}
			}
			if(up==true && basic==false && special==false){
				p1y-=3;
				if(right==true){
					g.drawImage(FJ,p1x,p1y,this);	
				}
				if(right==false){
					g.drawImage(FJL,p1x,p1y,this);	
				}
				
				if(p1yy-p1y==150 || onGround==true){
					up=false;
					
				}
			}
			if(up==false && onGround==false && basic==false && special==false){
				if(right==false){
					g.drawImage(FFL,p1x,p1y,this);	
					}
				if(right==true){
					g.drawImage(FF,p1x,p1y,this);	
					}
			}
			if(left==true && onGround==true && basic==false){
				if(timer>60){
					timer=0;
				}
				if(timer>0 && timer<=10){
					g.drawImage(FWL1,p1x,p1y,this);	
				}
				if(timer>10 && timer<=20){
					g.drawImage(FWL2,p1x,p1y,this);	
				}
				if(timer>20 && timer<=30){
					g.drawImage(FWL3,p1x,p1y,this);	
				}
				if(timer>30 && timer<=40){
					g.drawImage(FWL4,p1x,p1y,this);	
				}
				if(timer>40 && timer<=50){
					g.drawImage(FWL5,p1x,p1y,this);	
				}
				if(timer>50 && timer<=60){
					g.drawImage(FWL6,p1x,p1y,this);	
					timer=0;
				}
				
				
				
				
				}
		}
		if(choosen2==8){
			if(right2==false && left2==false && onGround2==true && basic2==false && special2==false){
				g.drawImage(Fox,p2x,p2y,this);
			}
			if(right2==true && onGround2==true && basic2==false && special2==false){
				if(timer2>60){
					timer2=0;
				}
				if(timer2>0 && timer2<=10){
					g.drawImage(FW1,p2x,p2y,this);	
				}
				if(timer2>10 && timer2<=20){
					g.drawImage(FW2,p2x,p2y,this);	
				}
				if(timer2>20 && timer2<=30){
					g.drawImage(FW3,p2x,p2y,this);	
				}
				if(timer2>30 && timer2<=40){
					g.drawImage(FW4,p2x,p2y,this);	
				}
				if(timer2>40 && timer2<=50){
					g.drawImage(FW5,p2x,p2y,this);	
				}
				if(timer2>50 && timer2<=60){
					g.drawImage(FW6,p2x,p2y,this);
					timer2=0;	
				}
				
				
			}
			if(basic2==true && special2==false){
				if(left2==true){
					if(timer2>0 && timer2<=20){
						g.drawImage(FPL1,p2x,p2y,this);	
					}
					if(timer2>20 && timer2<=40){
						g.drawImage(FPL2,p2x,p2y,this);	
					}
					if(timer2>40 && timer2<=60){
						g.drawImage(FPL3,p2x,p2y,this);	
					}
					if(timer2>60 && timer2<=80){
						g.drawImage(FPL4,p2x,p2y,this);	
					}
					if(timer2>80){
						basic2=false;
					}
				}
				if(left2==false){
					if(timer2>0 && timer2<=20){
						g.drawImage(FP1,p2x,p2y,this);	
					}
					if(timer2>20 && timer2<=40){
						g.drawImage(FP2,p2x,p2y,this);	
					}
					if(timer2>40 && timer2<=60){
						g.drawImage(FP3,p2x,p2y,this);	
					}
					if(timer2>60 && timer2<=80){
						g.drawImage(FP4,p2x,p2y,this);	
					}
					if(timer2>80){
						basic2=false;
					}
				}
			}
			if(basic2==false && special2==true){
				if(left2==true){
					if(timer2>0 && timer2<=30){
						g.drawImage(FSL1,p2x,p2y,this);	
					}
					if(timer2>30 && timer2<=60){
						g.drawImage(FSL2,p2x,p2y,this);	
					}
					if(timer2>60 && timer2<=90){
						g.drawImage(FSL3,p2x,p2y,this);	
					}
					if(timer2>90 && timer2<=120){
						g.drawImage(FSL4,p2x,p2y,this);	
					}
					if(timer2>120){
						special2=false;
					}
				}
				if(left2==false){
					if(timer2>0 && timer2<=30){
						g.drawImage(FS1,p2x,p2y,this);	
					}
					if(timer2>30 && timer2<=60){
						g.drawImage(FS2,p2x,p2y,this);	
					}
					if(timer2>60 && timer2<=90){
						g.drawImage(FS3,p2x,p2y,this);	
					}
					if(timer2>90 && timer2<=120){
						g.drawImage(FS4,p2x,p2y,this);	
					}
					if(timer2>120){
						special2=false;
					}
				}
			}
			if(up2==true && basic2==false && special2==false){
				p2y-=3;
				if(right2==true){
					g.drawImage(FJ,p2x,p2y,this);	
				}
				if(right2==false){
					g.drawImage(FJL,p2x,p2y,this);	
				}
				
				if(p2yy-p2y==150 || onGround2==true){
					up2=false;
					
				}
			}
			if(up2==false && onGround2==false && basic2==false && special2==false){
				if(right2==false){
					g.drawImage(FFL,p2x,p2y,this);	
					}
				if(right2==true){
					g.drawImage(FF,p2x,p2y,this);	
					}
			}
			if(left2==true && onGround2==true && basic2==false && special2==false){
				if(timer2>60){
					timer2=0;
				}
				if(timer2>0 && timer2<=10){
					g.drawImage(FWL1,p2x,p2y,this);	
				}
				if(timer2>10 && timer2<=20){
					g.drawImage(FWL2,p2x,p2y,this);	
				}
				if(timer2>20 && timer2<=30){
					g.drawImage(FWL3,p2x,p2y,this);	
				}
				if(timer2>30 && timer2<=40){
					g.drawImage(FWL4,p2x,p2y,this);	
				}
				if(timer2>40 && timer2<=50){
					g.drawImage(FWL5,p2x,p2y,this);	
				}
				if(timer2>50 && timer2<=60){
					g.drawImage(FWL6,p2x,p2y,this);	
					timer2=0;
				}
			}
		}
		if(choosen==6){
			if(right==false && left==false && onGround==true && basic==false && special==false){
				g.drawImage(Link,p1x,p1y,this);
			}
			if(right==true && onGround==true && basic==false && special==false){
				if(timer>60){
					timer=0;
				}
				if(timer>0 && timer<=10){
					g.drawImage(LW1,p1x,p1y,this);	
				}
				if(timer>10 && timer<=20){
					g.drawImage(LW2,p1x,p1y,this);	
				}
				if(timer>20 && timer<=30){
					g.drawImage(LW3,p1x,p1y,this);
				}
				if(timer>30 && timer<=40){
					g.drawImage(LW4,p1x,p1y,this);	
					
				}
				if(timer>40 && timer<=50){
					g.drawImage(LW5,p1x,p1y,this);	
				}
				if(timer>50 && timer<=60){
					g.drawImage(LW6,p1x,p1y,this);
					timer=0;	
				}
			}
			if(basic==false && special==true){
				if(left==true){
					if(timer>0 && timer<=20){
						g.drawImage(LSL1,p1x,p1y,this);	
					}
					if(timer>20 && timer<=80){
						g.drawImage(LSL2,p1x,p1y,this);	
					}
					if(timer>80 && timer<=100){
						g.drawImage(LSL3,p1x,p1y,this);	
					}
					if(timer>100 && timer<=120){
						g.drawImage(LSL4,p1x,p1y,this);	
					}
					if(timer>120){
						special=false;
					}
				}
				if(left==false){
					if(timer>0 && timer<=20){
						g.drawImage(LS1,p1x,p1y,this);	
					}
					if(timer>20 && timer<=80){
						g.drawImage(LS2,p1x,p1y,this);	
					}
					if(timer>80 && timer<=100){
						g.drawImage(LS3,p1x,p1y,this);	
					}
					if(timer>100 && timer<=120){
						g.drawImage(LS4,p1x,p1y,this);	
					}
					if(timer>120){
						special=false;
					}
				}
			}
			if(basic==true && special==false){
				if(left==true){
					if(timer>0 && timer<=20){
						g.drawImage(LPL1,p1x,p1y,this);	
					}
					if(timer>20 && timer<=40){
						g.drawImage(LPL2,p1x,p1y,this);	
					}
					if(timer>40 && timer<=60){
						g.drawImage(LPL3,p1x,p1y,this);	
					}
					if(timer>60 && timer<=80){
						g.drawImage(LPL4,p1x,p1y,this);	
					}
					if(timer>80){
						basic=false;
					}
				}
				if(left==false){
					if(timer>0 && timer<=20){
						g.drawImage(LP1,p1x,p1y,this);	
					}
					if(timer>20 && timer<=40){
						g.drawImage(LP2,p1x,p1y,this);	
					}
					if(timer>40 && timer<=60){
						g.drawImage(LP3,p1x,p1y,this);	
					}
					if(timer>60 && timer<=80){
						g.drawImage(LP4,p1x,p1y,this);	
					}
					if(timer>80){
						basic=false;
					}
				}
			}
			if(up==true && basic==false && special==false){
				p1y-=2;
				if(right==true){
					g.drawImage(LJ,p1x,p1y,this);	
				}
				if(right==false){
					g.drawImage(LJL,p1x,p1y,this);	
				}
				if(p1yy-p1y==150 || onGround==true){
					up=false;		
				}
			}
			if(up==false && onGround==false && basic==false && special==false){
				if(right==true){
					g.drawImage(LJ,p1x,p1y,this);	
					}
				if(right==false){
					g.drawImage(LJL,p1x,p1y,this);	
					}
			}
			
			if(left==true && onGround==true && basic==false && special==false){
				if(timer>60){
					timer=0;
				}
				if(timer>0 && timer<=10){
					g.drawImage(LWL1,p1x,p1y,this);	
				}
				if(timer>10 && timer<=20){
					g.drawImage(LWL2,p1x,p1y,this);	
				}
				if(timer>20 && timer<=30){
					g.drawImage(LWL3,p1x,p1y,this);
				}
				if(timer>30 && timer<=40){
					g.drawImage(LWL4,p1x,p1y,this);	
				}
				if(timer>40 && timer<=50){
					g.drawImage(LWL5,p1x,p1y,this);	
				}
				if(timer>50 && timer<=60){
					g.drawImage(LWL6,p1x,p1y,this);
					timer=0;	
				}
			}
		}
		if(choosen2==6){
			if(right2==false && left2==false && onGround2==true && basic2==false && special2==false){
				g.drawImage(Link,p2x,p2y,this);
			}
			if(right2==true && onGround2==true && basic2==false && special2==false){
				if(timer2>60){
					timer2=0;
				}
				if(timer2>0 && timer2<=10){
					g.drawImage(LW1,p2x,p2y,this);	
				}
				if(timer2>10 && timer2<=20){
					g.drawImage(LW2,p2x,p2y,this);	
				}
				if(timer2>20 && timer2<=30){
					g.drawImage(LW3,p2x,p2y,this);
				}
				if(timer2>30 && timer2<=40){
					g.drawImage(LW4,p2x,p2y,this);	
					
				}
				if(timer2>40 && timer2<=50){
					g.drawImage(LW5,p2x,p2y,this);	
				}
				if(timer2>50 && timer2<=60){
					g.drawImage(LW6,p2x,p2y,this);
					timer2=0;	
				}
			}
			if(basic2==true && special2==false){
				if(left2==true){
					if(timer2>0 && timer2<=20){
						g.drawImage(LPL1,p2x,p2y,this);	
					}
					if(timer2>20 && timer2<=40){
						g.drawImage(LPL2,p2x,p2y,this);	
					}
					if(timer2>40 && timer2<=60){
						g.drawImage(LPL3,p2x,p2y,this);	
					}
					if(timer2>60 && timer2<=80){
						g.drawImage(LPL4,p2x,p2y,this);	
					}
					if(timer2>80){
						basic2=false;
					}
				}
				if(left2==false){
					if(timer2>0 && timer2<=20){
						g.drawImage(LP1,p2x,p2y,this);	
					}
					if(timer2>20 && timer2<=40){
						g.drawImage(LP2,p2x,p2y,this);	
					}
					if(timer2>40 && timer2<=60){
						g.drawImage(LP3,p2x,p2y,this);	
					}
					if(timer2>60 && timer2<=80){
						g.drawImage(LP4,p2x,p2y,this);	
					}
					if(timer2>80){
						basic2=false;
					}
				}
			}
			if(basic2==false && special2==true){
				if(left2==true){
					if(timer2>0 && timer2<=20){
						g.drawImage(LSL1,p2x,p2y,this);	
					}
					if(timer2>20 && timer2<=80){
						g.drawImage(LSL2,p2x,p2y,this);	
					}
					if(timer2>80 && timer2<=100){
						g.drawImage(LSL3,p2x,p2y,this);	
					}
					if(timer2>100 && timer2<=120){
						g.drawImage(LSL4,p2x,p2y,this);	
					}
					if(timer2>120){
						special2=false;
					}
				}
				if(left2==false){
					if(timer2>0 && timer2<=20){
						g.drawImage(LS1,p2x,p2y,this);	
					}
					if(timer2>20 && timer2<=80){
						g.drawImage(LS2,p2x,p2y,this);	
					}
					if(timer2>80 && timer2<=100){
						g.drawImage(LS3,p2x,p2y,this);	
					}
					if(timer2>100 && timer2<=120){
						g.drawImage(LS4,p2x,p2y,this);	
					}
					if(timer2>120){
						special2=false;
					}
				}
			}
			if(up2==true && basic2==false && special2==false){
				p2y-=2;
				if(right2==true){
					g.drawImage(LJ,p2x,p2y,this);	
				}
				if(right2==false){
					g.drawImage(LJL,p2x,p2y,this);	
				}
				if(p2yy-p2y==150 || onGround2==true){
					up2=false;		
				}
			}
			if(up2==false && onGround2==false && basic2==false && special2==false){
				if(right2==true){
					g.drawImage(LJ,p2x,p2y,this);	
					}
				if(right2==false){
					g.drawImage(LJL,p2x,p2y,this);	
					}
			}
			if(left2==true && onGround2==true && basic2==false && special2==false){
				if(timer2>60){
					timer2=0;
				}
				if(timer2>0 && timer2<=10){
					g.drawImage(LWL1,p2x,p2y,this);	
				}
				if(timer2>10 && timer2<=20){
					g.drawImage(LWL2,p2x,p2y,this);	
				}
				if(timer2>20 && timer2<=30){
					g.drawImage(LWL3,p2x,p2y,this);
				}
				if(timer2>30 && timer2<=40){
					g.drawImage(LWL4,p2x,p2y,this);	
					
				}
				if(timer2>40 && timer2<=50){
					g.drawImage(LWL5,p2x,p2y,this);	
				}
				if(timer2>50 && timer2<=60){
					g.drawImage(LWL6,p2x,p2y,this);
					timer2=0;	
				}
			}
		}
		
		if(choosen==5){
			if(right==false && left==false && onGround==true && basic==false && special==false){
				g.drawImage(Pikachu,p1x,p1y,this);
			}
			if(right==true && onGround==true && basic==false && special==false){
				if(timer>40){
					timer=0;
				}
				if(timer>0 && timer<=10){
					g.drawImage(PiW1,p1x,p1y,this);	
				}
				if(timer>10 && timer<=20){
					g.drawImage(PiW2,p1x,p1y,this);	
				}
				if(timer>20 && timer<=30){
					g.drawImage(PiW3,p1x,p1y,this);	
				}
				if(timer>30 && timer<=40){
					g.drawImage(PiW4,p1x,p1y,this);
					timer=0;	
				}
				
				
			}
			if(basic==true && special==false){
				if(left==false){
					if(timer>0 && timer<=16){
						g.drawImage(Pikachu,p1x,p1y,this);	
					}
					if(timer>16 && timer<=32){
						g.drawImage(PiP1,p1x,p1y,this);	
					}
					if(timer>32 && timer<=48){

						g.drawImage(PiP2,p1x,p1y,this);	
					}
					if(timer>48 && timer<=64){
						i+=1;
						g.drawImage(PiP3,p1x+1,p1y,this);	
					}
					if(timer>64 && timer<=80){
						i-=1;
						g.drawImage(PiP4,p1x+i,p1y,this);	
					}
					if(timer>80){
						i=0;
						basic=false;
					}
				}
				if(left==true){
					if(timer>0 && timer<=16){
						g.drawImage(PiL,p1x,p1y,this);	
					}
					if(timer>16 && timer<=32){
						g.drawImage(PiPL1,p1x,p1y,this);	
					}
					if(timer>32 && timer<=48){
						i+=1;
						g.drawImage(PiPL2,p1x+1,p1y,this);	
					}
					if(timer>48 && timer<=64){
						
						g.drawImage(PiPL3,p1x,p1y,this);	
					}
					if(timer>64 && timer<=80){
						g.drawImage(PiPL4,p1x,p1y,this);	
					}
					if(timer>80){
						i=0;
						basic=false;
					}
				}					
				}
				
			if(basic==false && special==true){
				if(left==false){
					if(timer>0 && timer<=30){
						g.drawImage(PiS1,p1x,p1y,this);	
					}
					if(timer>30 && timer<=60){
						g.drawImage(PiS2,p1x,p1y,this);	
					}
					if(timer>60 && timer<=80){
						g.drawImage(PiS3,p1x,p1y,this);	
					}
					if(timer>80 && timer<=100){
						g.drawImage(PiS4,p1x,p1y,this);	
					}
					if(timer>100 && timer<=120){
						
						g.drawImage(PiS5,p1x,p1y,this);	
					}
					if(timer>120){
						i=0;
						special=false;
					}
				}
				if(left==true){
					if(timer>0 && timer<=30){
						g.drawImage(PiSL1,p1x,p1y,this);	
					}
					if(timer>30 && timer<=60){
						g.drawImage(PiSL2,p1x,p1y,this);	
					}
					if(timer>60 && timer<=80){
						g.drawImage(PiSL3,p1x,p1y,this);	
					}
					if(timer>80 && timer<=100){
						g.drawImage(PiSL4,p1x,p1y,this);	
					}
					if(timer>100 && timer<=120){
						
						g.drawImage(PiSL5,p1x,p1y,this);	
					}
					if(timer>120){
						i=0;
						special=false;
					}
				}					
				}
			if(up==true && special==false){
				p1y-=3;
				if(timer>40){
					timer=0;
				}
				if(timer>0 && timer<=10){
					g.drawImage(PiJ1,p1x,p1y,this);	
				}	
				if(timer>10 && timer<=20){
					g.drawImage(PiJ2,p1x,p1y,this);	
				}
				if(timer>20 && timer<=30){
					g.drawImage(PiJ3,p1x,p1y,this);	
				}
				if(timer>30 && timer<=40){
					g.drawImage(PiJ4,p1x,p1y,this);
					timer=0;
						
				}
				
				if(p1yy-p1y==150 || onGround==true){
					up=false;
				
				}
				
		}
			if(up==false && onGround==false && basic==false && special==false){
				if(timer>40){
					timer=0;
				}
				if(timer>0 && timer<=10){
					g.drawImage(PiF1,p1x,p1y,this);	
				}	
				if(timer>10 && timer<=20){
					g.drawImage(PiF2,p1x,p1y,this);	
				}
				if(timer>20 && timer<=30){
					g.drawImage(PiF3,p1x,p1y,this);	
				}
				if(timer>30 && timer<=40){
					g.drawImage(PiF4,p1x,p1y,this);
					timer=0;	
				}
				
			}
			if(left==true && onGround==true && basic==false && special==false){
				if(timer>40){
					timer=0;
				}
				if(timer>0 && timer<=10){
					g.drawImage(PiWL1,p1x,p1y,this);	
				}
				if(timer>10 && timer<=20){
					g.drawImage(PiWL2,p1x,p1y,this);	
				}
				if(timer>20 && timer<=30){
					g.drawImage(PiWL3,p1x,p1y,this);	
				}
				if(timer>30 && timer<=40){
					g.drawImage(PiWL4,p1x,p1y,this);
					timer=0;	
				}
			
			
			
			}
		
		}
		if(choosen2==5){
			if(right2==false && left2==false && onGround2==true && basic2==false && special2==false){
				g.drawImage(Pikachu,p2x,p2y,this);
			}
			if(right2==true && onGround2==true && basic2==false && special2==false){
				if(timer2>40){
					timer2=0;
				}
				if(timer2>0 && timer2<=10){
					g.drawImage(PiW1,p2x,p2y,this);	
				}
				if(timer2>10 && timer2<=20){
					g.drawImage(PiW2,p2x,p2y,this);	
				}
				if(timer2>20 && timer2<=30){
					g.drawImage(PiW3,p2x,p2y,this);	
				}
				if(timer2>30 && timer2<=40){
					g.drawImage(PiW4,p2x,p2y,this);
					timer2=0;	
				}
				
				
			}
			if(basic2==true && special2==false){
				if(left2==false){
					if(timer2>0 && timer2<=16){
						g.drawImage(Pikachu,p2x,p2y,this);	
					}
					if(timer2>16 && timer2<=32){
						g.drawImage(PiP1,p2x,p2y,this);	
					}
					if(timer2>32 && timer2<=48){

						g.drawImage(PiP2,p2x,p2y,this);	
					}
					if(timer2>48 && timer2<=64){
						i+=1;
						g.drawImage(PiP3,p2x+1,p2y,this);	
					}
					if(timer2>64 && timer2<=80){
						i-=1;
						g.drawImage(PiP4,p2x+i,p2y,this);	
					}
					if(timer2>80){
						i=0;
						basic2=false;
					}
				}
				if(left2==true){
					if(timer2>0 && timer2<=16){
						g.drawImage(PiL,p2x,p2y,this);	
					}
					if(timer2>16 && timer2<=32){
						g.drawImage(PiPL1,p2x,p2y,this);	
					}
					if(timer2>32 && timer2<=48){
						
						g.drawImage(PiPL2,p2x,p2y,this);	
					}
					if(timer2>48 && timer2<=64){
						i+=1;
						g.drawImage(PiPL3,p2x+i,p2y,this);	
					}
					if(timer2>64 && timer2<=80){
						i-=1;
						g.drawImage(PiPL4,p2x+i,p2y,this);	
					}
					if(timer2>80){
						i=0;
						basic2=false;
					}
				}					
				}
			if(basic2==false && special2==true){
				if(left2==false){
					if(timer2>0 && timer2<=30){
						g.drawImage(PiS1,p2x,p2y,this);	
					}
					if(timer2>30 && timer2<=60){
						g.drawImage(PiS2,p2x,p2y,this);	
					}
					if(timer2>60 && timer2<=80){
						g.drawImage(PiS3,p2x,p2y,this);	
					}
					if(timer2>80 && timer2<=100){
						g.drawImage(PiS4,p2x,p2y,this);	
					}
					if(timer2>100 && timer2<=120){
						
						g.drawImage(PiS5,p2x,p2y,this);	
					}
					if(timer2>120){
						i=0;
						special2=false;
					}
				}
				if(left2==true){
					if(timer2>0 && timer2<=30){
						g.drawImage(PiSL1,p2x,p2y,this);	
					}
					if(timer2>30 && timer2<=60){
						g.drawImage(PiSL2,p2x,p2y,this);	
					}
					if(timer2>60 && timer2<=80){
						g.drawImage(PiSL3,p2x,p2y,this);	
					}
					if(timer2>80 && timer2<=100){
						g.drawImage(PiSL4,p2x,p2y,this);	
					}
					if(timer2>100 && timer2<=120){
						
						g.drawImage(PiSL5,p2x,p2y,this);	
					}
					if(timer2==120){
						i=0;
						special2=false;
					}
				}					
				}
			if(up2==true && basic2==false && special2==false){
				p2y-=3;
				if(timer2>40){
					timer2=0;
				}
				if(timer2>0 && timer2<=10){
					g.drawImage(PiJ1,p2x,p2y,this);	
				}	
				if(timer2>10 && timer2<=20){
					g.drawImage(PiJ2,p2x,p2y,this);	
				}
				if(timer2>20 && timer2<=30){
					g.drawImage(PiJ3,p2x,p2y,this);	
				}
				if(timer2>30 && timer2<=40){
					g.drawImage(PiJ4,p2x,p2y,this);
					timer2=0;
						
				}
				
				if(p2yy-p2y==150 || onGround2==true){
					up2=false;
				
				}
				
		}
			if(up2==false && onGround2==false && basic2==false && special2==false){
				if(timer2>40){
					timer2=0;
				}
				if(timer2>0 && timer2<=10){
					g.drawImage(PiF1,p2x,p2y,this);	
				}	
				if(timer2>10 && timer2<=20){
					g.drawImage(PiF2,p2x,p2y,this);	
				}
				if(timer2>20 && timer2<=30){
					g.drawImage(PiF3,p2x,p2y,this);	
				}
				if(timer2>30 && timer2<=40){
					g.drawImage(PiF4,p2x,p2y,this);
					timer2=0;	
				}
				
			}
			if(left2==true && onGround2==true && basic2==false && special2==false){
				if(timer2>40){
					timer2=0;
				}
				if(timer2>0 && timer2<=10){
					g.drawImage(PiWL1,p2x,p2y,this);	
				}
				if(timer2>10 && timer2<=20){
					g.drawImage(PiWL2,p2x,p2y,this);	
				}
				if(timer2>20 && timer2<=30){
					g.drawImage(PiWL3,p2x,p2y,this);	
				}
				if(timer2>30 && timer2<=40){
					g.drawImage(PiWL4,p2x,p2y,this);
					timer2=0;	
				}
			
			
			
			}
		
		}
		if(choosen==2){
			if(right==false && left==false && onGround==true && basic==false && special==false){
				g.drawImage(Luigi,p1x,p1y,this);
			}
			if(right==true && onGround==true && basic==false && special==false){
				if(timer>80){
					timer=0;
				}
				if(timer>0 && timer<=10){
					g.drawImage(LuW1,p1x,p1y,this);	
				}
				if(timer>10 && timer<=20){
					g.drawImage(LuW2,p1x,p1y,this);	
				}
				if(timer>20 && timer<=30){
					g.drawImage(LuW3,p1x,p1y,this);
				}
				if(timer>30 && timer<=40){
					g.drawImage(LuW4,p1x,p1y,this);	
					
				}
				if(timer>40 && timer<=50){
					g.drawImage(LuW5,p1x,p1y,this);	
				}
				if(timer>50 && timer<=60){
					g.drawImage(LuW6,p1x,p1y,this);
						
				}
				if(timer>60 && timer<=70){
					g.drawImage(LuW5,p1x,p1y,this);	
				}
				if(timer>70 && timer<=80){
					g.drawImage(LuW6,p1x,p1y,this);
					timer=0;	
				}
			}
			if(basic==true && special==false){
				if(left==false){
					if(timer>0 && timer<=20){
					g.drawImage(LuP1,p1x,p1y,this);
				
					}
					if(timer>20 && timer<=40){
						g.drawImage(LuP2,p1x,p1y,this);	
					}
					if(timer>40 && timer<=60){
						g.drawImage(LuP3,p1x,p1y,this);
					}
					if(timer>60 && timer<=80){
						g.drawImage(LuP4,p1x,p1y,this);	
						
					}
					if(timer>80){
						basic=false;
					}
				}
				if(left==true){
					if(timer>0 && timer<=20){
					g.drawImage(LuPL1,p1x,p1y,this);
				
					}
					if(timer>20 && timer<=40){
						g.drawImage(LuPL2,p1x,p1y,this);	
					}
					if(timer>40 && timer<=60){
						g.drawImage(LuPL3,p1x,p1y,this);
					}
					if(timer>60 && timer<=80){
						g.drawImage(LuPL4,p1x,p1y,this);	
						
					}
					if(timer>80){
						basic=false;
					}
				}
				
			}
			if(basic==false && special==true){
				if(left==false){
					if(timer>0 && timer<=40){
					g.drawImage(LuS1,p1x,p1y,this);
				
					}
					if(timer>40 && timer<=60){
						g.drawImage(LuS2,p1x,p1y,this);	
					}
					if(timer>60 && timer<=80){
						g.drawImage(LuS3,p1x,p1y,this);
					}
					if(timer>80 && timer<=100){
						g.drawImage(LuS4,p1x,p1y,this);	
						
					}
					if(timer>100 && timer<=120){
						g.drawImage(LuS5,p1x,p1y,this);	
						
					}
					if(timer>120){
						special=false;
					}
				}
				if(left==true){
					if(timer>0 && timer<=40){
					g.drawImage(LuSL1,p1x,p1y,this);
				
					}
					if(timer>40 && timer<=60){
						g.drawImage(LuSL2,p1x,p1y,this);	
					}
					if(timer>60 && timer<=80){
						g.drawImage(LuSL3,p1x,p1y,this);
					}
					if(timer>80 && timer<=100){
						g.drawImage(LuSL4,p1x,p1y,this);	
						
					}
					if(timer>100 && timer<=120){
						g.drawImage(LuSL5,p1x,p1y,this);	
						
					}
					if(timer>120){
						special=false;
					}
				}
				
			}
			if(up==true && basic==false && special==false){
				p1y-=2;
				if(right==true){
					g.drawImage(LuJ,p1x,p1y,this);	
				}
				if(right==false){
					g.drawImage(LuJL,p1x,p1y,this);	
				}
				if(p1yy-p1y==150 || onGround==true){
					up=false;		
				}
			}
			if(up==false && onGround==false && basic==false && special==false){
				if(right==true){
					if(timer>40){
						timer=0;
					}
					if(timer>0 && timer<=10){
						g.drawImage(LuF1,p1x,p1y,this);	
					}
					if(timer>10 && timer<=20){
						g.drawImage(LuF2,p1x,p1y,this);	
					}
					if(timer>20 && timer<=30){
						g.drawImage(LuF3,p1x,p1y,this);
					}
					if(timer>30 && timer<=40){
						g.drawImage(LuF4,p1x,p1y,this);	
						timer=0;
					}
						
				}
			if(right==false ){
				if(timer>40){
					timer=0;
				}
				if(timer>0 && timer<=10){
					g.drawImage(LuFL1,p1x,p1y,this);	
				}
				if(timer>10 && timer<=20){
					g.drawImage(LuFL2,p1x,p1y,this);	
				}
				if(timer>20 && timer<=30){
					g.drawImage(LuFL3,p1x,p1y,this);
				}
				if(timer>30 && timer<=40){
					g.drawImage(LuFL4,p1x,p1y,this);	
					timer=0;
				}	
				}
		}
			if(left==true && onGround==true && basic==false && special==false){
				if(timer>80){
					timer=0;
				}
				if(timer>0 && timer<=10){
					g.drawImage(LuWL1,p1x,p1y,this);	
				}
				if(timer>10 && timer<=20){
					g.drawImage(LuWL2,p1x,p1y,this);	
				}
				if(timer>20 && timer<=30){
					g.drawImage(LuWL3,p1x,p1y,this);
				}
				if(timer>30 && timer<=40){
					g.drawImage(LuWL4,p1x,p1y,this);	
					
				}
				if(timer>40 && timer<=50){
					g.drawImage(LuWL5,p1x,p1y,this);	
				}
				if(timer>50 && timer<=60){
					g.drawImage(LuWL6,p1x,p1y,this);	
				}
				if(timer>60 && timer<=70){
					g.drawImage(LuWL7,p1x,p1y,this);	
				}
				if(timer>70 && timer<=80){
					g.drawImage(LuWL8,p1x,p1y,this);
					timer=0;	
				}
			}
		}

		
		if(choosen==9){
			if(right==false && left==false && onGround==true && basic==false && special==false){
				g.drawImage(Sonic,p1x,p1y,this);
			}
			if(right==true && onGround==true && basic==false && special==false){
				if(timer>70){
					timer=0;
				}
				if(timer>0 && timer<=10){
					g.drawImage(SW1,p1x,p1y,this);	
				}
				if(timer>10 && timer<=20){
					g.drawImage(SW2,p1x,p1y,this);	
				}
				if(timer>20 && timer<=30){
					g.drawImage(SW3,p1x,p1y,this);	
				}
				if(timer>30 && timer<=40){
					g.drawImage(SW4,p1x,p1y,this);	
				}
				if(timer>40 && timer<=50){
					g.drawImage(SW5,p1x,p1y,this);	
				}
				if(timer>50 && timer<=60){
					g.drawImage(SW6,p1x,p1y,this);	
				}
				if(timer>60 && timer<=70){
					g.drawImage(SW7,p1x,p1y,this);	
					timer=0;
				}
				
				
				
			}
			if(basic==true && special==false){
				if(left==true){
					if(timer>0 && timer<=20){
						g.drawImage(SPL1,p1x,p1y,this);	
					}
					if(timer>20 && timer<=40){
						g.drawImage(SPL2,p1x,p1y,this);	
					}
					if(timer>40 && timer<=60){
						g.drawImage(SPL3,p1x,p1y,this);	
					}
					if(timer>60 && timer<=80){
						g.drawImage(SPL4,p1x,p1y,this);	
					}
					if(timer>80){
						basic=false;
					}
				}
				if(left==false){
					if(timer>0 && timer<=20){
						g.drawImage(SP1,p1x,p1y,this);	
					}
					if(timer>20 && timer<=40){
						g.drawImage(SP2,p1x,p1y,this);	
					}
					if(timer>40 && timer<=60){
						g.drawImage(SP3,p1x,p1y,this);	
					}
					if(timer>60 && timer<=80){
						g.drawImage(SP4,p1x,p1y,this);	
					}
					if(timer>80){
						basic=false;
					}
				}
			}
			if(basic==false && special==true){
				if(left==true){
					if(timer>0 && timer<=30){
						g.drawImage(SSL1,p1x,p1y,this);	
					}
					if(timer>30 && timer<=60){
						g.drawImage(SSL2,p1x,p1y,this);	
					}
					if(timer>60 && timer<=70){
						g.drawImage(SSL3,p1x,p1y,this);	
					}
					if(timer>70 && timer<=80){
						g.drawImage(SSL4,p1x,p1y,this);	
					}
					if(timer>80 && timer<=90){
						g.drawImage(SSL5,p1x,p1y,this);	
					}
					if(timer>90 && timer<=100){
						g.drawImage(SSL6,p1x,p1y,this);	
					}
					if(timer>100 && timer<=110){
						g.drawImage(SSL7,p1x,p1y,this);	
					}
					if(timer>110 && timer<=120){
						g.drawImage(SSL8,p1x,p1y,this);	
					}
					if(timer>120){
						special=false;
					}
				}
				if(left==false){
					if(timer>0 && timer<=30){
						g.drawImage(SS1,p1x,p1y,this);	
					}
					if(timer>30 && timer<=60){
						g.drawImage(SS2,p1x,p1y,this);	
					}
					if(timer>60 && timer<=70){
						g.drawImage(SS3,p1x,p1y,this);	
					}
					if(timer>70 && timer<=80){
						g.drawImage(SS4,p1x,p1y,this);	
					}
					if(timer>80 && timer<=90){
						g.drawImage(SS5,p1x,p1y,this);	
					}
					if(timer>90 && timer<=100){
						g.drawImage(SS6,p1x,p1y,this);	
					}
					if(timer>100 && timer<=110){
						g.drawImage(SS7,p1x,p1y,this);	
					}
					if(timer>110 && timer<=120){
						g.drawImage(SS8,p1x,p1y,this);	
					}
					if(timer>120){
						special=false;
					}
				}
			}
		if(up==true && basic==false && special==false){
			p1y-=3;
			if(right==true){
				g.drawImage(SJ,p1x,p1y,this);	
			}
			if(right==false){
				g.drawImage(SJL,p1x,p1y,this);	
			}
			
			if(p1yy-p1y==150 || onGround==true){
				up=false;
				
			}
		}
		if(up==false && onGround==false && basic==false && special==false){
			if(right==false){
				g.drawImage(SFL,p1x,p1y,this);	
				}
			if(right==true){
				g.drawImage(SF,p1x,p1y,this);	
				}
		}
		if(left==true && onGround==true && basic==false && special==false){
			if(timer>70){
				timer=0;
			}
			if(timer>0 && timer<=10){
				g.drawImage(SWL1,p1x,p1y,this);	
			}
			if(timer>10 && timer<=20){
				g.drawImage(SWL2,p1x,p1y,this);	
			}
			if(timer>20 && timer<=30){
				g.drawImage(SWL3,p1x,p1y,this);	
			}
			if(timer>30 && timer<=40){
				g.drawImage(SWL4,p1x,p1y,this);	
			}
			if(timer>40 && timer<=50){
				g.drawImage(SWL5,p1x,p1y,this);	
			}
			if(timer>50 && timer<=60){
				g.drawImage(SWL6,p1x,p1y,this);	
			}
			if(timer>60 && timer<=70){
				g.drawImage(SWL7,p1x,p1y,this);	
				timer=0;
			}		
		}
	}
		System.out.println(p1y-p2y);
		if(choosen2==9){
			if(right2==false && left2==false && onGround2==true && basic2==false && special2==false){
				g.drawImage(Sonic,p2x,p2y,this);
			}
			if(right2==true && onGround2==true && basic2==false && special2==false){
				if(timer2>70){
					timer2=0;
				}
				if(timer2>0 && timer2<=10){
					g.drawImage(SW1,p2x,p2y,this);	
				}
				if(timer2>10 && timer2<=20){
					g.drawImage(SW2,p2x,p2y,this);	
				}
				if(timer2>20 && timer2<=30){
					g.drawImage(SW3,p2x,p2y,this);	
				}
				if(timer2>30 && timer2<=40){
					g.drawImage(SW4,p2x,p2y,this);	
				}
				if(timer2>40 && timer2<=50){
					g.drawImage(SW5,p2x,p2y,this);	
				}
				if(timer2>50 && timer2<=60){
					g.drawImage(SW6,p2x,p2y,this);	
				}
				if(timer2>60 && timer2<=70){
					g.drawImage(SW7,p2x,p2y,this);	
					timer2=0;
				}
				
				
				
			}
			if(basic2==true && special2==false){
				if(left2==true){
					if(timer2>0 && timer2<=20){
						g.drawImage(SPL1,p2x,p2y,this);	
					}
					if(timer2>20 && timer2<=40){
						g.drawImage(SPL2,p2x,p2y,this);	
					}
					if(timer2>40 && timer2<=60){
						g.drawImage(SPL3,p2x,p2y,this);	
					}
					if(timer2>60 && timer2<=80){
						g.drawImage(SPL4,p2x,p2y,this);	
					}
					if(timer2>80){
						basic2=false;
					}
				}
				if(left2==false){
					if(timer2>0 && timer2<=20){
						g.drawImage(SP1,p2x,p2y,this);	
					}
					if(timer2>20 && timer2<=40){
						g.drawImage(SP2,p2x,p2y,this);	
					}
					if(timer2>40 && timer2<=60){
						g.drawImage(SP3,p2x,p2y,this);	
					}
					if(timer2>60 && timer2<=80){
						g.drawImage(SP4,p2x,p2y,this);	
					}
					if(timer2>80){
						basic2=false;
					}
				}
			}
			if(basic2==false && special2==true){
				if(left2==true){
					if(timer2>0 && timer2<=30){
						g.drawImage(SSL1,p2x,p2y,this);	
					}
					if(timer2>30 && timer2<=60){
						g.drawImage(SSL2,p2x,p2y,this);	
					}
					if(timer2>60 && timer2<=70){
						g.drawImage(SSL3,p2x,p2y,this);	
					}
					if(timer2>70 && timer2<=80){
						g.drawImage(SSL4,p2x,p2y,this);	
					}
					if(timer2>80 && timer2<=90){
						g.drawImage(SSL5,p2x,p2y,this);	
					}
					if(timer2>90 && timer2<=100){
						g.drawImage(SSL6,p2x,p2y,this);	
					}
					if(timer2>100 && timer2<=110){
						g.drawImage(SSL7,p2x,p2y,this);	
					}
					if(timer2>110 && timer2<=120){
						g.drawImage(SSL8,p2x,p2y,this);	
					}
					if(timer2>120){
						special2=false;
					}
				}
				if(left2==false){
					if(timer2>0 && timer2<=30){
						g.drawImage(SS1,p2x,p2y,this);	
					}
					if(timer2>30 && timer2<=60){
						g.drawImage(SS2,p2x,p2y,this);	
					}
					if(timer2>60 && timer2<=70){
						g.drawImage(SS3,p2x,p2y,this);	
					}
					if(timer2>70 && timer2<=80){
						g.drawImage(SS4,p2x,p2y,this);	
					}
					if(timer2>80 && timer2<=90){
						g.drawImage(SS5,p2x,p2y,this);	
					}
					if(timer2>90 && timer2<=100){
						g.drawImage(SS6,p2x,p2y,this);	
					}
					if(timer2>100 && timer2<=110){
						g.drawImage(SS7,p2x,p2y,this);	
					}
					if(timer2>110 && timer2<=120){
						g.drawImage(SS8,p2x,p2y,this);	
					}
					if(timer2>120){
						special2=false;
					}
				}
			}
			
			if(up2==true && basic2==false){
				p2y-=3;
				if(right2==true){
					g.drawImage(SJ,p2x,p2y,this);	
				}
				if(right2==false){
					g.drawImage(SJL,p2x,p2y,this);	
				}
				
				if(p2yy-p2y==150 || onGround2==true){
					up2=false;
					
				}
			}
			if(up2==false && onGround2==false && basic2==false && special2==false){
				if(right2==false){
					g.drawImage(SFL,p2x,p2y,this);	
					}
				if(right2==true){
					g.drawImage(SF,p2x,p2y,this);	
					}
			}
			if(left2==true && onGround2==true && basic2==false && special2==false){
				if(timer2>70){
					timer2=0;
				}
				if(timer2>0 && timer2<=10){
					g.drawImage(SWL1,p2x,p2y,this);	
				}
				if(timer2>10 && timer2<=20){
					g.drawImage(SWL2,p2x,p2y,this);	
				}
				if(timer2>20 && timer2<=30){
					g.drawImage(SWL3,p2x,p2y,this);	
				}
				if(timer2>30 && timer2<=40){
					g.drawImage(SWL4,p2x,p2y,this);	
				}
				if(timer2>40 && timer2<=50){
					g.drawImage(SWL5,p2x,p2y,this);	
				}
				if(timer2>50 && timer2<=60){
					g.drawImage(SWL6,p2x,p2y,this);	
				}
				if(timer2>60 && timer2<=70){
					g.drawImage(SWL7,p2x,p2y,this);	
					timer2=0;
				}		
			}
	}
		if(choosen==10){
		
			if(right==false && left==false && onGround==true && basic==false && special==false){
				g.drawImage(Tails,p1x,p1y,this);
			}
			if(right==true && onGround==true && basic==false && special==false){
				if(timer>70){
					timer=0;
				}
				if(timer>0 && timer<=10){
					g.drawImage(TW1,p1x,p1y,this);	
				}
				if(timer>10 && timer<=20){
					g.drawImage(TW2,p1x,p1y,this);	
				}
				if(timer>20 && timer<=30){
					g.drawImage(TW3,p1x,p1y,this);	
				}
				if(timer>30 && timer<=40){
					g.drawImage(TW4,p1x,p1y,this);	
				}
				if(timer>40 && timer<=50){
					g.drawImage(TW5,p1x,p1y,this);	
				}
				if(timer>50 && timer<=60){
					g.drawImage(TW6,p1x,p1y,this);
					timer=0;	
				}
				if(timer>60 && timer<=70){
					g.drawImage(TW7,p1x,p1y,this);
					timer=0;	
				}
				
				
				
				
			}
			if(basic==true && special==false){
				if(left==false){
					if(timer>0 && timer<=13){
						g.drawImage(TP1,p1x,p1y,this);	
					}
					if(timer>13 && timer<=27){
						g.drawImage(TP2,p1x,p1y,this);	
					}
					if(timer>27 && timer<=40){
						g.drawImage(TP3,p1x,p1y,this);	
					}
					if(timer>40 && timer<=53){
						g.drawImage(TP4,p1x,p1y,this);	
					}
					if(timer>53 && timer<=67){
						g.drawImage(TP5,p1x+1,p1y,this);	
					}
					if(timer>67 && timer<=80){
						g.drawImage(TP6,p1x,p1y,this);	
					}
					if(timer>80){
						basic=false;
					}
				}
				if(left==true){
					if(timer>0 && timer<=13){
						g.drawImage(TPL6,p1x,p1y,this);	
					}
					if(timer>13 && timer<=27){
						g.drawImage(TPL5,p1x,p1y,this);	
					}
					if(timer>27 && timer<=40){
						g.drawImage(TPL4,p1x,p1y,this);	
					}
					if(timer>40 && timer<=53){
						g.drawImage(TPL3,p1x,p1y,this);	
					}
					if(timer>53 && timer<=67){
						g.drawImage(TPL2,p1x,p1y,this);	
					}
					if(timer>67 && timer<=80){
						g.drawImage(TPL1,p1x,p1y,this);	
					}
					if(timer>80){
						basic=false;
					}
				}					
				}
			if(basic==false && special==true){	
				if(left==false){
					
				
					if(timer>0 && timer<=24){
						g.drawImage(TS1,p1x,p1y,this);	
						}
					if(timer>24 && timer<=48){
						g.drawImage(TS2,p1x,p1y,this);	
					}
					if(timer>48 && timer<=72){
						g.drawImage(TS3,p1x,p1y,this);	
					}
					if(timer>72 && timer<=96){
						g.drawImage(TS4,p1x,p1y,this);	
					}
					if(timer>96 && timer<=120){
						g.drawImage(TS5,p1x,p1y,this);	
					}
					if(timer==120){
						special=false;
					}
				}
				if(left==true){
					
				
					if(timer>0 && timer<=24){
							g.drawImage(TSL1,p1x,p1y,this);	
						}
					if(timer>24 && timer<=48){
						g.drawImage(TSL2,p1x,p1y,this);	
					}
					if(timer>48 && timer<=72){
						g.drawImage(TSL3,p1x,p1y,this);	
					}
					if(timer>72 && timer<=96){
						g.drawImage(TSL4,p1x,p1y,this);	
					}
					if(timer>96 && timer<=120){
						g.drawImage(TSL5,p1x,p1y,this);	
					}
					if(timer==120){
						special=false;
					}
				}
				
			}
			
			
			if(up==true && basic==false && special==false){
				p1y-=3;
				if(right==true){
					g.drawImage(TJ,p1x,p1y,this);	
				}
				if(right==false){
					g.drawImage(TJL,p1x,p1y,this);	
				}
				
				if(p1yy-p1y==150 || onGround==true){
					up=false;
					
				}
			}
			if(up==false && onGround==false  && basic==false && special==false){
				if(right==false){
					g.drawImage(TFL,p1x,p1y,this);	
					}
				if(right==true){
					g.drawImage(TF,p1x,p1y,this);	
					}
			}
			if(left==true && onGround==true && basic==false && special==false){
				if(timer>70){
					timer=0;
				}
				if(timer>0 && timer<=10){
					g.drawImage(TWL1,p1x,p1y,this);	
				}
				if(timer>10 && timer<=20){
					g.drawImage(TWL2,p1x,p1y,this);	
				}
				if(timer>20 && timer<=30){
					g.drawImage(TWL3,p1x,p1y,this);	
				}
				if(timer>30 && timer<=40){
					g.drawImage(TWL4,p1x,p1y,this);	
				}
				if(timer>40 && timer<=50){
					g.drawImage(TWL5,p1x,p1y,this);	
				}
				if(timer>50 && timer<=60){
					g.drawImage(TWL6,p1x,p1y,this);	
					timer=0;
				}
				if(timer>60 && timer<=70){
					g.drawImage(TWL7,p1x,p1y,this);	
					timer=0;
				}
			}
		}
		if(choosen2==10){
			if(right2==false && left2==false && onGround2==true && basic2==false && special2==false){
				g.drawImage(Tails,p2x,p2y,this);
			}
			if(right2==true && onGround2==true && basic2==false && special2==false){
				if(timer2>70){
					timer2=0;
				}
				if(timer2>0 && timer2<=10){
					g.drawImage(TW1,p2x,p2y,this);	
				}
				if(timer2>10 && timer2<=20){
					g.drawImage(TW2,p2x,p2y,this);	
				}
				if(timer2>20 && timer2<=30){
					g.drawImage(TW3,p2x,p2y,this);	
				}
				if(timer2>30 && timer2<=40){
					g.drawImage(TW4,p2x,p2y,this);	
				}
				if(timer2>40 && timer2<=50){
					g.drawImage(TW5,p2x,p2y,this);	
				}
				if(timer2>50 && timer2<=60){
					g.drawImage(TW6,p2x,p2y,this);
					timer=0;	
				}
				if(timer2>60 && timer2<=70){
					g.drawImage(TW7,p2x,p2y,this);
					timer2=0;	
				}
				
			}
			if(basic2==true && special2==false){
				if(left2==false){
					if(timer2>0 && timer2<=13){
						g.drawImage(TP1,p2x,p2y,this);	
					}
					if(timer2>13 && timer2<=27){
						g.drawImage(TP2,p2x,p2y,this);	
					}
					if(timer2>27 && timer2<=40){
						g.drawImage(TP3,p2x,p2y,this);	
					}
					if(timer2>40 && timer2<=53){
						g.drawImage(TP4,p2x,p2y,this);	
					}
					if(timer2>53 && timer2<=67){
						g.drawImage(TP5,p2x,p2y,this);	
					}
					if(timer2>67 && timer2<=80){
						g.drawImage(TP6,p2x,p2y,this);	
					}
					if(timer2>80){
						basic2=false;
					}
				}
				if(left2==true){
					if(timer2>0 && timer2<=13){
						g.drawImage(TPL6,p2x,p2y,this);	
					}
					if(timer2>13 && timer2<=27){
						g.drawImage(TPL5,p2x,p2y,this);	
					}
					if(timer2>27 && timer2<=40){
						g.drawImage(TPL4,p2x,p2y,this);	
					}
					if(timer2>40 && timer2<=53){
						g.drawImage(TPL3,p2x,p2y,this);	
					}
					if(timer2>53 && timer2<=67){
						g.drawImage(TPL2,p2x,p2y,this);	
					}
					if(timer2>67 && timer2<=80){
						g.drawImage(TPL1,p2x,p2y,this);	
					}
					if(timer2>80){
						basic2=false;
					}
				}					
				}
			if(basic2==false && special2==true){	
				if(left2==false){
					
				
					if(timer2>0 && timer2<=24){
						g.drawImage(TS1,p2x,p2y,this);	
						}
					if(timer2>24 && timer2<=48){
						g.drawImage(TS2,p2x,p2y,this);	
					}
					if(timer2>48 && timer2<=72){
						g.drawImage(TS3,p2x,p2y,this);	
					}
					if(timer2>72 && timer2<=96){
						g.drawImage(TS4,p2x,p2y,this);	
					}
					if(timer2>96 && timer2<=120){
						g.drawImage(TS5,p2x,p2y,this);	
					}
					if(timer2==120){
						special2=false;
					}
				}
				if(left2==true){
					
				
					if(timer2>0 && timer2<=24){
						g.drawImage(TSL5,p2x,p2y,this);	
						}
					if(timer2>24 && timer2<=48){
						g.drawImage(TSL4,p2x,p2y,this);	
					}
					if(timer2>48 && timer2<=72){
						g.drawImage(TSL3,p2x,p2y,this);	
					}
					if(timer2>72 && timer2<=96){
						g.drawImage(TSL2,p2x,p2y,this);	
					}
					if(timer2>96 && timer2<=120){
						g.drawImage(TSL1,p2x,p2y,this);	
					}
					if(timer2==120){
						special2=false;
					}
				}
				
			}
			if(up2==true && basic2==false && special2==false){
				p2y-=3;
				if(right2==true){
					g.drawImage(TJ,p2x,p2y,this);	
				}
				if(right2==false){
					g.drawImage(TJL,p2x,p2y,this);	
				}
				
				if(p2yy-p2y==150 || onGround2==true){
					up2=false;
					
				}
			}
			if(up2==false && onGround2==false && basic2==false && special2==false){
				if(right==false){
					g.drawImage(TFL,p2x,p2y,this);	
					}
				if(right==true){
					g.drawImage(TF,p2x,p2y,this);	
					}
			}
			if(left2==true && onGround2==true && basic2==false && special2==false){
				if(timer2>70){
					timer2=0;
				}
				if(timer2>0 && timer2<=10){
					g.drawImage(TWL1,p2x,p2y,this);	
				}
				if(timer2>10 && timer2<=20){
					g.drawImage(TWL2,p2x,p2y,this);	
				}
				if(timer2>20 && timer2<=30){
					g.drawImage(TWL3,p2x,p2y,this);	
				}
				if(timer2>30 && timer2<=40){
					g.drawImage(TWL4,p2x,p2y,this);	
				}
				if(timer2>40 && timer2<=50){
					g.drawImage(TWL5,p2x,p2y,this);	
				}
				if(timer2>50 && timer2<=60){
					g.drawImage(TWL6,p2x,p2y,this);	
				}
				if(timer2>60 && timer2<=70){
					g.drawImage(TWL7,p2x,p2y,this);	
					timer2=0;
				}
			}
		}
		timer+=1;
		timer2+=1;
    }
		
}





    



    
